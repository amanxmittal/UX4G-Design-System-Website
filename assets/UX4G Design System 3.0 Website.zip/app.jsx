/* global React, ReactDOM */
const { useState, useEffect, useRef, useCallback } = React;

/* ───────────────── Toast system ───────────────── */
function useToasts() {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2400);
  }, []);
  return { toasts, push };
}

function Toasts({ items }) {
  return (
    <div className="toast-stack">
      {items.map((t) => (
        <div className="toast" key={t.id}>
          <span className="t-mark">i</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

/* ───────────────── Navbar ───────────────── */
function Navbar({ onStub, onExplore, active, setActive }) {
  const links = [
    { l: "Foundations", href: "UX4G Foundations.html" },
    { l: "Fundamentals", href: "UX4G Fundamentals.html" },
    { l: "Components", href: "UX4G Components.html" },
    { l: "Patterns", href: "UX4G Patterns.html" },
  ];
  return (
    <header className="nav">
      <div className="nav-inner">
        <a className="brand" href="UX4G Homepage.html">
          <div className="brand-mark">U4</div>
          <div className="brand-text">
            <div className="row">
              <span className="wordmark">UX4G</span>
              <span className="sub">Design System</span>
            </div>
            <span className="gov">A Government of India Initiative</span>
          </div>
        </a>
        <nav className="nav-links">
          {links.map((x) => (
            <a
              key={x.l}
              href={x.href}
              className={"nav-link" + ("NEVER_MATCH" === x.l ? " active" : "")}
            >
              {x.l}
            </a>
          ))}
        </nav>
        <button className="btn btn-primary" onClick={onExplore}>
          Explore components <span className="btn-arrow">→</span>
        </button>
      </div>
    </header>
  );
}

/* ───────────────── Hero ───────────────── */
function HeroPreview() {
  const [otp, setOtp] = useState(["4", "8", "3", "", "", ""]);
  const [progress, setProgress] = useState(64);
  const otpRefs = useRef([]);

  const setCell = (i, v) => {
    if (!/^[0-9]?$/.test(v)) return;
    setOtp((prev) => {
      const next = [...prev];
      next[i] = v;
      return next;
    });
    if (v && i < 5) otpRefs.current[i + 1]?.focus();
  };
  const onKey = (i, e) => {
    if (e.key === "Backspace" && !otp[i] && i > 0) otpRefs.current[i - 1]?.focus();
  };

  useEffect(() => {
    const t = setInterval(() => setProgress((p) => (p >= 92 ? 64 : p + 2)), 900);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="hero-preview">
      <div className="preview-card">
        <div className="label">
          <span><span className="live-dot"></span>Input / OTP</span>
          <span className="right">otp.tsx</span>
        </div>
        <label className="cmp-input-label">Enter the 6-digit code sent to +91 ●●●●● ●●234</label>
        <div className="cmp-otp">
          {otp.map((v, i) => (
            <input
              key={i}
              ref={(el) => (otpRefs.current[i] = el)}
              className={"cmp-otp-cell" + (v ? " filled" : "")}
              value={v}
              maxLength={1}
              onChange={(e) => setCell(i, e.target.value)}
              onKeyDown={(e) => onKey(i, e)}
              inputMode="numeric"
            />
          ))}
        </div>
        <div className="cmp-input-help">
          <span>Didn't receive? Resend in 0:24</span>
          <span style={{ color: "var(--primary)", fontWeight: 600 }}>Verify →</span>
        </div>
      </div>

      <div className="preview-card">
        <div className="label">
          <span><span className="live-dot"></span>Status pipeline · Grievance #GR-3429</span>
          <span className="right">2 of 4</span>
        </div>
        <div className="cmp-pipeline">
          <div className="progress-line" style={{ width: "42%" }}></div>
          <div className="step done"><div className="node">✓</div><div className="label">Submitted</div></div>
          <div className="step active"><div className="node">2</div><div className="label">Under review</div></div>
          <div className="step"><div className="node">3</div><div className="label">Action taken</div></div>
          <div className="step"><div className="node">4</div><div className="label">Resolved</div></div>
        </div>
      </div>

      <div className="preview-card">
        <div className="label">
          <span><span className="live-dot"></span>SLA indicator · Right to Service</span>
          <span className="right">on track</span>
        </div>
        <div className="cmp-sla">
          <div className="sla-head">
            <span className="sla-title">Certificate issuance, 21 working days</span>
            <span className="sla-time">11 days remaining</span>
          </div>
          <div className="cmp-progress">
            <div className="track">
              <div className="fill" style={{ width: progress + "%" }}></div>
            </div>
          </div>
          <div className="sla-foot">
            <span>FILED 14 APR</span><span>DUE 05 MAY</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Hero({ onStub }) {
  return (
    <section className="hero">
      <div className="container hero-inner">
        <div className="hero-left">
          <span className="hero-tag"><span className="pulse"></span>v3.0 · Released April 2026</span>
          <h1 className="hero-headline">
            A design system<br />
            built for the <span className="em">complexity</span><br />
            of <span className="underline-amber">Indian public services</span>.
          </h1>
          <p className="hero-sub">
            55+ components, 6 service patterns, and accessibility primitives that account for Aadhaar
            authentication, multilingual layouts and statutory SLAs, not bolted on after.
          </p>
          <div className="hero-ctas">
            <a className="btn btn-primary btn-lg" href="UX4G Components.html">
              Browse components <span className="btn-arrow">→</span>
            </a>
            <a className="btn btn-ghost-dark btn-lg" href="UX4G Foundations.html">
              View foundations
            </a>
          </div>
          <div className="hero-terms">
            <span className="hero-term primary">Aadhaar auth</span>
            <span className="hero-term">OTP verification</span>
            <span className="hero-term">Grievance filing</span>
            <span className="hero-term">Certificate issuance</span>
            <span className="hero-term accent">22 Indic scripts</span>
            <span className="hero-term">DPDP 2023 consent</span>
            <span className="hero-term">SLA indicators</span>
            <span className="hero-term">DigiLocker</span>
          </div>
        </div>
        <div className="hero-right">
          <HeroPreview />
        </div>
      </div>
    </section>
  );
}

/* ───────────────── Section: India-specific ───────────────── */
function SpecificSection() {
  const cols = [
    {
      num: "01 / Service",
      title: "Government service patterns, built in.",
      body: "Aadhaar authentication, grievance filing, certificate issuance, OTP flows. Not generic UI, actual service design decisions, made once, shared across ministries.",
      tags: ["Aadhaar OTP", "Grievance", "Certificate", "DigiLocker", "ePramaan"],
    },
    {
      num: "02 / Script",
      title: "22 Indian languages, supported by default.",
      body: "Noto Sans across all official scripts. Script-aware line-height, contextual numerals, and number-system switching for Devanagari, Tamil, Bengali and more.",
      tags: ["हिन्दी", "தமிழ்", "বাংলা", "ગુજરાતી", "ਪੰਜਾਬੀ", "ಕನ್ನಡ"],
    },
    {
      num: "03 / Compliance",
      title: "Compliance is not an afterthought.",
      body: "WCAG 2.1 AA contrast and focus order, DPDP Act 2023 consent surfaces, and Right to Service SLA indicators ship as primitives, not as something a team has to retrofit.",
      tags: ["WCAG 2.1 AA", "DPDP 2023", "RTS Act", "GIGW 3.0"],
    },
  ];
  return (
    <section className="section specific">
      <div className="container">
        <div className="specific-head">
          <div>
            <span className="eyebrow"><span className="dot"></span>Why a separate system</span>
            <h2>Why a separate system</h2>
          </div>
          <p>
            UX4G is built on three premises that you can't easily retrofit into a system designed for
            consumer SaaS. Each one is opinionated, and each one is the reason this exists.
          </p>
        </div>
        <div className="specific-grid">
          {cols.map((c, i) => (
            <div className="specific-col" key={i}>
              <div className="specific-num">{c.num}</div>
              <h3>{c.title}</h3>
              <p>{c.body}</p>
              <div className="tags">
                {c.tags.map((t) => <span className="specific-tag" key={t}>{t}</span>)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────────────── Section: live numbers ───────────────── */
function NumbersSection() {
  const items = [
    { big: "55", suffix: "+", label: "Components live", sub: "ACROSS 8 GROUPS" },
    { big: "6", suffix: "", label: "Patterns live", sub: "IDENTITY & ACCESS" },
    { big: "22", suffix: "", label: "Languages", sub: "OFFICIAL SCRIPTS" },
    { big: "AA", suffix: "", label: "WCAG 2.1 conformance", sub: "AUDITED Q1 2026", compact: true },
  ];
  return (
    <section className="numbers">
      <div className="container">
        <div className="numbers-head">
          <div className="title">By the numbers</div>
          <div className="meta">LAST UPDATED · 28.04.2026</div>
        </div>
        <div className="numbers-grid">
          {items.map((n, i) => (
            <div className="number-cell" key={i}>
              <div className={"big" + (n.compact ? " compact" : "")}>
                <span>{n.big}</span>
                {n.suffix && <span className="suffix">{n.suffix}</span>}
              </div>
              <div className="label">{n.label}</div>
              <div className="sub">{n.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────────────── Section: component showcase ───────────────── */
function ShowcaseCheckbox({ initial = false, label }) {
  const [on, setOn] = useState(initial);
  return (
    <div className="cmp-checkbox" onClick={() => setOn(!on)}>
      <div className={"box" + (on ? " checked" : "")}></div>
      <span>{label}</span>
    </div>
  );
}
function ShowcaseRadio({ initial = false, label }) {
  const [on, setOn] = useState(initial);
  return (
    <div className="cmp-radio" onClick={() => setOn(!on)}>
      <div className={"ring" + (on ? " on" : "")}></div>
      <span>{label}</span>
    </div>
  );
}
function ShowcaseToggle({ initial = false }) {
  const [on, setOn] = useState(initial);
  return <div className={"cmp-toggle" + (on ? " on" : "")} onClick={() => setOn(!on)}></div>;
}

function ShowcaseOtp() {
  const [vals, setVals] = useState(["1", "9", "4", "7", "", ""]);
  const refs = useRef([]);
  const set = (i, v) => {
    if (!/^[0-9]?$/.test(v)) return;
    const next = [...vals]; next[i] = v; setVals(next);
    if (v && i < 5) refs.current[i + 1]?.focus();
  };
  return (
    <div className="cmp-otp">
      {vals.map((v, i) => (
        <input
          key={i}
          ref={(el) => (refs.current[i] = el)}
          className={"cmp-otp-cell" + (v ? " filled" : "")}
          value={v}
          maxLength={1}
          onChange={(e) => set(i, e.target.value)}
          style={{ width: 40, height: 48, fontSize: 18 }}
          inputMode="numeric"
        />
      ))}
    </div>
  );
}

function ShowcaseSection({ onStub }) {
  return (
    <section className="showcase">
      <div className="container">
        <div className="showcase-head">
          <div>
            <span className="eyebrow"><span className="dot"></span>The system, rendered</span>
            <h2>Component showcase</h2>
          </div>
          <p>
            Everything below is live UX4G, same code, same tokens, same accessibility behaviour you'd
            ship. No screenshots, no mock-ups.
          </p>
        </div>

        {/* Group 1: Form elements */}
        <div className="cmp-group">
          <div className="label-col">
            <div className="group-name">Form elements</div>
            <div className="group-count">12 components</div>
            <a className="group-link" onClick={() => onStub("Form elements")}>View all <span>→</span></a>
          </div>
          <div className="cmp-row row-2">
            <div className="cmp-tile">
              <div className="tile-label">Text input · with label</div>
              <label className="cmp-input-label">Full name (as on Aadhaar)</label>
              <input className="cmp-input" defaultValue="Anjali Bhattacharya" />
              <div className="cmp-input-help"><span>Required · matches your records</span><span>32 / 60</span></div>
            </div>
            <div className="cmp-tile">
              <div className="tile-label">OTP input</div>
              <label className="cmp-input-label">6-digit verification code</label>
              <ShowcaseOtp />
              <div className="cmp-input-help"><span>Resend in 0:42</span><span>via SMS</span></div>
            </div>
            <div className="cmp-tile">
              <div className="tile-label">Selection controls</div>
              <div style={{ display: "grid", gap: 12 }}>
                <ShowcaseCheckbox initial={true} label="I consent to processing my data under DPDP Act, 2023" />
                <ShowcaseCheckbox label="Send me service notifications via SMS" />
                <div style={{ display: "flex", gap: 24, marginTop: 4 }}>
                  <ShowcaseRadio initial={true} label="Aadhaar OTP" />
                  <ShowcaseRadio label="DigiLocker" />
                  <ShowcaseRadio label="ePramaan" />
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 4 }}>
                  <ShowcaseToggle initial={true} />
                  <span style={{ fontSize: 14, color: "var(--gray-700)" }}>High-contrast mode</span>
                </div>
              </div>
            </div>
            <div className="cmp-tile">
              <div className="tile-label">File upload · dropzone</div>
              <div className="cmp-upload">
                <div className="icon-box">PDF</div>
                <div>
                  <div className="title">Drop your supporting document, or click to browse</div>
                  <div className="meta">Aadhaar / PAN / Ration card · PDF, JPG up to 4MB</div>
                </div>
              </div>
              <div className="cmp-input-help" style={{ marginTop: 12 }}>
                <span>1 file required</span><span style={{ color: "var(--primary)" }}>Browse →</span>
              </div>
            </div>
          </div>
        </div>

        {/* Group 2: Feedback */}
        <div className="cmp-group">
          <div className="label-col">
            <div className="group-name">Feedback</div>
            <div className="group-count">7 components</div>
            <a className="group-link" onClick={() => onStub("Feedback")}>View all <span>→</span></a>
          </div>
          <div className="cmp-row row-2">
            <div className="cmp-tile">
              <div className="tile-label">Alert · success</div>
              <div className="cmp-alert success">
                <div className="a-icon">✓</div>
                <div className="a-body">
                  <div className="a-title">Application submitted to District Magistrate's office.</div>
                  <div className="a-text">Reference number AP-2025-DM-83942 has been sent to your registered mobile.</div>
                </div>
              </div>
            </div>
            <div className="cmp-tile">
              <div className="tile-label">Alert · warning</div>
              <div className="cmp-alert warning">
                <div className="a-icon">!</div>
                <div className="a-body">
                  <div className="a-title">Your session will expire in 1 minute 24 seconds.</div>
                  <div className="a-text">Save your draft to continue this application later from the dashboard.</div>
                </div>
              </div>
            </div>
            <div className="cmp-tile">
              <div className="tile-label">Status badges</div>
              <div className="cmp-badges">
                <span className="badge success"><span className="b-dot"></span>Verified</span>
                <span className="badge info"><span className="b-dot"></span>Under review</span>
                <span className="badge warning"><span className="b-dot"></span>Action required</span>
                <span className="badge danger"><span className="b-dot"></span>Rejected</span>
                <span className="badge neutral"><span className="b-dot"></span>Draft</span>
                <span className="badge info">+3 more</span>
              </div>
            </div>
            <div className="cmp-tile">
              <div className="tile-label">Progress · multi-step</div>
              <div className="cmp-progress">
                <div className="track"><div className="fill" style={{ width: "67%" }}></div></div>
                <div className="meta">
                  <span>STEP 4 OF 6</span><span>67% COMPLETE</span>
                </div>
              </div>
              <div style={{ marginTop: 14 }}>
                <div className="cmp-progress">
                  <div className="track"><div className="fill" style={{ width: "100%", background: "var(--success)" }}></div></div>
                  <div className="meta"><span>UPLOAD COMPLETE</span><span>1.2 MB / 1.2 MB</span></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Group 3: Data display */}
        <div className="cmp-group">
          <div className="label-col">
            <div className="group-name">Data display</div>
            <div className="group-count">9 components</div>
            <a className="group-link" onClick={() => onStub("Data display")}>View all <span>→</span></a>
          </div>
          <div className="cmp-row row-2">
            <div className="cmp-tile">
              <div className="tile-label">Status pipeline</div>
              <div style={{ paddingTop: 8 }}>
                <div className="cmp-pipeline">
                  <div className="progress-line" style={{ width: "60%" }}></div>
                  <div className="step done"><div className="node">✓</div><div className="label">Filed</div></div>
                  <div className="step done"><div className="node">✓</div><div className="label">Acknowledged</div></div>
                  <div className="step active"><div className="node">3</div><div className="label">Field verification</div></div>
                  <div className="step"><div className="node">4</div><div className="label">Issued</div></div>
                </div>
              </div>
            </div>
            <div className="cmp-tile">
              <div className="tile-label">SLA indicator</div>
              <div className="cmp-sla">
                <div className="sla-head">
                  <span className="sla-title">Income certificate · 30-day SLA</span>
                  <span className="sla-time">18 days left</span>
                </div>
                <div className="sla-bar">
                  <div className="seg done" style={{ width: "40%" }}></div>
                </div>
                <div className="sla-foot">
                  <span>FILED 02 APR 2026</span><span>DUE 02 MAY 2026</span>
                </div>
              </div>
              <div className="cmp-sla" style={{ marginTop: 16 }}>
                <div className="sla-head">
                  <span className="sla-title">Property mutation · 45-day SLA</span>
                  <span className="sla-time warn">3 days left</span>
                </div>
                <div className="sla-bar">
                  <div className="seg warn" style={{ width: "93%" }}></div>
                </div>
                <div className="sla-foot">
                  <span>FILED 14 MAR 2026</span><span>DUE 28 APR 2026</span>
                </div>
              </div>
            </div>
            <div className="cmp-tile">
              <div className="tile-label">Empty state</div>
              <div className="cmp-empty">
                <div className="empty-icon">∅</div>
                <div className="empty-title">No applications in this stage yet</div>
                <div className="empty-sub">Once you file an application, you'll see its status here. Track up to 12 months.</div>
                <button className="btn btn-primary" style={{ marginTop: 12 }}>
                  Start an application
                </button>
              </div>
            </div>
            <div className="cmp-tile">
              <div className="tile-label">Dropdown · language switcher</div>
              <div className="cmp-select">
                <span>English (en-IN)</span>
                <span className="caret">▾</span>
              </div>
              <div style={{ marginTop: 12 }}>
                <div className="cmp-select">
                  <span>हिन्दी (Hindi)</span>
                  <span className="caret">▾</span>
                </div>
              </div>
              <div className="cmp-input-help" style={{ marginTop: 12 }}>
                <span>22 official languages</span><span style={{ color: "var(--primary)" }}>Browse all →</span>
              </div>
            </div>
          </div>
        </div>

        <div style={{ marginTop: 48, display: "flex", justifyContent: "center" }}>
          <button className="btn btn-ghost btn-lg" onClick={() => onStub("All components")}>
            View all 55+ components <span className="btn-arrow">→</span>
          </button>
        </div>
      </div>
    </section>
  );
}

/* ───────────────── Section: patterns ───────────────── */
function PatternsSection({ onStub }) {
  const live = [
    { n: "P-01", name: "Sign In",            desc: "Aadhaar OTP, DigiLocker SSO, and password as third option. With session-timeout handling." },
    { n: "P-02", name: "Sign Up",            desc: "Account creation with mobile-first verification, consent capture under DPDP, and language selection." },
    { n: "P-03", name: "OTP Verification",   desc: "6-digit verification, resend logic, fallback to call. Same rhythm across all services." },
    { n: "P-04", name: "Session Timeout",    desc: "Warn-extend-save pattern for long forms. Drafts persisted, never lost on logout." },
    { n: "P-05", name: "Forgot Password",    desc: "Recovery via registered mobile or email, branches based on what's verified, no dead ends." },
    { n: "P-06", name: "Auth Error & Lockout", desc: "Failed attempts, lockout windows, support handoffs. Messages tested across literacy levels." },
  ];
  const soon = [
    "Consent & Declaration",
    "Application & Submission",
    "Status & Tracking",
    "Payment",
    "Notifications",
    "Feedback",
  ];
  return (
    <section className="patterns">
      <div className="container">
        <div className="patterns-head">
          <div>
            <span className="eyebrow"><span className="dot"></span>Patterns, not just components</span>
            <h2>Service patterns</h2>
          </div>
          <p>
            Components are pieces. Patterns are how they fit together for a real journey, sign-in, application, payment, grievance.
          </p>
        </div>

        <div className="patterns-section-label">
          <span className="live-pill">LIVE · 6</span>
          <span>Identity &amp; Access</span>
          <div className="line"></div>
          <span>v3.0</span>
        </div>
        <div className="patterns-grid">
          {live.map((p) => (
            <div className="pattern-card" key={p.n} onClick={() => onStub(p.name)}>
              <div className="p-num">{p.n}</div>
              <div className="p-name">{p.name}</div>
              <div className="p-desc">{p.desc}</div>
              <div className="p-foot">
                <span className="p-live"><span className="ld"></span>Live</span>
                <span className="p-arrow">↗</span>
              </div>
            </div>
          ))}
        </div>

        <div className="patterns-section-label">
          <span style={{
            background: "transparent",
            border: "1px solid var(--gray-300)",
            color: "var(--gray-700)",
            borderRadius: 4, padding: "3px 8px", fontSize: "10.5px", letterSpacing: "0.06em",
          }}>COMING · 6 GROUPS</span>
          <span>Roadmap · Q3, Q4 2026</span>
          <div className="line"></div>
        </div>
        <div className="patterns-soon">
          {soon.map((s, i) => (
            <div className="pattern-soon" key={s}>
              <span className="ps-name">{s}</span>
              <span className="ps-meta">Q{i < 3 ? "3" : "4"} · 2026</span>
            </div>
          ))}
        </div>

        <div className="patterns-cta">
          <a className="btn btn-primary btn-lg" href="UX4G Identity %26 Access.html">
            Explore Identity &amp; Access patterns <span className="btn-arrow">→</span>
          </a>
        </div>
      </div>
    </section>
  );
}

/* ───────────────── Footer ───────────────── */
function Footer({ onStub }) {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-inner">
          <div className="footer-brand">
            <div className="wm">UX4G</div>
            <div className="desc">
              A Government of India initiative under NeGD, MeitY and the Digital India programme, open
              for any ministry, agency or state portal that serves Indian citizens.
            </div>
          </div>
          <div className="footer-col">
            <h4>The system</h4>
            <ul>
              <li><a href="UX4G Foundations.html">Foundations</a></li>
              <li><a href="UX4G Fundamentals.html">Fundamentals</a></li>
              <li><a href="UX4G Components.html">Components</a></li>
              <li><a href="UX4G Patterns.html">Patterns</a></li>
              <li><a onClick={() => onStub("Changelog")}>Changelog · v3.0</a></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Built for India.</h4>
            <ul>
              <li><a onClick={() => onStub("Contribute")}>Contribute on GitHub</a></li>
              <li><a onClick={() => onStub("Feedback")}>Submit feedback</a></li>
              <li><a onClick={() => onStub("Accessibility")}>Accessibility statement</a></li>
              <li><a onClick={() => onStub("Get in touch")}>Get in touch</a></li>
            </ul>
            <span className="tag">Open for all.</span>
          </div>
        </div>
        <div className="tricolour" style={{ width: "100%", borderRadius: 0, height: 3 }}>
          <span className="s"></span><span className="w"></span><span className="g"></span>
        </div>
        <div className="footer-bar">
          <span>© 2026 · NATIONAL E-GOVERNANCE DIVISION · MEITY</span>
          <span>UX4G · DESIGN SYSTEM 3.0 · MADE IN INDIA</span>
        </div>
      </div>
    </footer>
  );
}

/* ───────────────── App ───────────────── */
function App() {
  const { toasts, push } = useToasts();
  const [active, setActive] = useState("");

  const stub = (name) => push(`${name}, page coming soon`);

  return (
    <>
      <Navbar
        onStub={stub}
        onExplore={() => stub("Explore components")}
        active={active}
        setActive={setActive}
      />
      <main>
        <Hero onStub={stub} />
        <SpecificSection />
        <NumbersSection />
        <ShowcaseSection onStub={stub} />
        <PatternsSection onStub={stub} />
      </main>
      <Footer onStub={stub} />
      <Toasts items={toasts} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
