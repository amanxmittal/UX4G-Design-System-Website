/* global React, ReactDOM */
const { useState, useCallback } = React;

function useToasts() {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2400);
  }, []);
  return { toasts, push };
}
function Toasts({ items }) {
  return (
    <div className="toast-stack">
      {items.map((t) => (
        <div className="toast" key={t.id}>
          <span className="t-mark">i</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}
function Navbar({ onStub }) {
  const links = [
    { l: "Foundations", href: "UX4G Foundations.html" },
    { l: "Fundamentals", href: "UX4G Fundamentals.html" },
    { l: "Components", href: "UX4G Components.html" },
    { l: "Patterns", href: "UX4G Patterns.html" },
  ];
  return (
    <header className="nav">
      <div className="nav-inner">
        <a className="brand" href="UX4G Homepage.html">
          <div className="brand-mark">U4</div>
          <div className="brand-text">
            <div className="row">
              <span className="wordmark">UX4G</span>
              <span className="sub">Design System</span>
            </div>
            <span className="gov">A Government of India Initiative</span>
          </div>
        </a>
        <nav className="nav-links">
          {links.map((x) => (
            <a key={x.l}
               className={"nav-link" + ("Fundamentals" === x.l ? " active" : "")}
               href={x.href}
            >{x.l}</a>
          ))}
        </nav>
        <a className="btn btn-primary" href="UX4G Homepage.html">← Home</a>
      </div>
    </header>
  );
}

/* Small SVG ornaments for the two live cards, quiet, not iconographic */
function OrnA11y() {
  return (
    <svg className="fu-orn" viewBox="0 0 84 84" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="42" cy="42" r="40" stroke="#6A4EFF" strokeWidth="1.5" />
      <circle cx="42" cy="42" r="28" stroke="#6A4EFF" strokeWidth="1.5" />
      <circle cx="42" cy="42" r="16" stroke="#6A4EFF" strokeWidth="1.5" />
      <circle cx="42" cy="42" r="4" fill="#6A4EFF" />
    </svg>
  );
}
function OrnContent() {
  return (
    <svg className="fu-orn" viewBox="0 0 84 84" fill="none" xmlns="http://www.w3.org/2000/svg">
      <line x1="8" y1="20" x2="76" y2="20" stroke="#6A4EFF" strokeWidth="1.5" />
      <line x1="8" y1="34" x2="64" y2="34" stroke="#6A4EFF" strokeWidth="1.5" />
      <line x1="8" y1="48" x2="76" y2="48" stroke="#6A4EFF" strokeWidth="1.5" />
      <line x1="8" y1="62" x2="48" y2="62" stroke="#6A4EFF" strokeWidth="1.5" />
    </svg>
  );
}

function App() {
  const { toasts, push } = useToasts();
  const stub = (n) => push(`${n}, page coming soon`);

  return (
    <>
      <Navbar onStub={stub} />
      <main className="fu-page">
        <section className="fu-header">
          <div className="container">
            <div className="fu-crumb">
              <a href="UX4G Homepage.html">Home</a>
              <span className="sep">/</span>
              <span className="current">Fundamentals</span>
            </div>
            <h1 className="fu-h">Fundamentals</h1>
            <p className="fu-desc">
              The principles and guidance behind every UX4G decision. Understanding these makes every component and pattern easier to apply correctly.
            </p>
          </div>
        </section>

        <section className="fu-grid-wrap">
          <div className="container">
            <div className="fu-grid">
              <div className="fu-card live" onClick={() => stub("Accessibility guide")}>
                <OrnA11y />
                <div className="fu-top">
                  <span className="fu-num">FU-01</span>
                  <span className="fu-status live"><span className="ld"></span>Live</span>
                </div>
                <h2 className="fu-name">Accessibility</h2>
                <p className="fu-text">
                  How UX4G meets WCAG 2.1 AA, supports assistive technologies, and ensures every citizen can use government digital services regardless of ability. Covers focus management, contrast, keyboard navigation, screen reader patterns, and the testing protocol every team should run before launch.
                </p>
                <div className="fu-foot">
                  <span className="pages">7 chapters · 24 min read</span>
                  <span className="fu-link">Read guide →</span>
                </div>
              </div>

              <div className="fu-card live" onClick={() => stub("Content guide")}>
                <OrnContent />
                <div className="fu-top">
                  <span className="fu-num">FU-02</span>
                  <span className="fu-status live"><span className="ld"></span>Live</span>
                </div>
                <h2 className="fu-name">Content</h2>
                <p className="fu-text">
                  Writing principles, plain language standards, and guidance for communicating clearly in English and across 22 Indian languages. Includes voice and tone, error message patterns, form labels, button text, and how to write for citizens whose primary language isn't the one they're reading.
                </p>
                <div className="fu-foot">
                  <span className="pages">9 chapters · 31 min read</span>
                  <span className="fu-link">Read guide →</span>
                </div>
              </div>

              <div className="fu-card soon">
                <div className="fu-top">
                  <span className="fu-num">FU-03</span>
                  <span className="fu-status soon">Coming soon</span>
                </div>
                <h2 className="fu-name">Inclusive Design</h2>
                <p className="fu-text">
                  Guidance for designing services that work for low-literacy users, first-time smartphone users, and citizens in low-bandwidth environments. Practical patterns for graceful degradation, voice-first interactions, and progressive disclosure across the full range of Indian device contexts.
                </p>
                <div className="fu-foot">
                  <span className="pages">In design</span>
                  <span className="fu-link">Coming soon</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="fu-why">
          <div className="container">
            <h2>Why fundamentals matter</h2>
            <div className="cols">
              <div className="col">
                <div className="cap">REASON · 01</div>
                <h3>Before components</h3>
                <div className="rule"></div>
                <p>Understanding accessibility and content principles makes component choices obvious rather than arbitrary.</p>
              </div>
              <div className="col">
                <div className="cap">REASON · 02</div>
                <h3>Shared language</h3>
                <div className="rule"></div>
                <p>When everyone on a service team understands these fundamentals, reviews and decisions happen faster and with less conflict.</p>
              </div>
              <div className="col">
                <div className="cap">REASON · 03</div>
                <h3>Built for India's scale</h3>
                <div className="rule"></div>
                <p>Government services reach citizens with vastly different abilities, literacy levels, languages, and devices. These fundamentals account for that range.</p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Toasts items={toasts} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
