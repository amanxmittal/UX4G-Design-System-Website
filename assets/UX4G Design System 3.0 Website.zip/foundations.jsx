/* global React, ReactDOM */
const { useState, useCallback } = React;

function useToasts() {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2400);
  }, []);
  return { toasts, push };
}
function Toasts({ items }) {
  return (
    <div className="toast-stack">
      {items.map((t) => (
        <div className="toast" key={t.id}>
          <span className="t-mark">i</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}
function Navbar({ onStub }) {
  const links = [
    { l: "Foundations", href: "UX4G Foundations.html" },
    { l: "Fundamentals", href: "UX4G Fundamentals.html" },
    { l: "Components", href: "UX4G Components.html" },
    { l: "Patterns", href: "UX4G Patterns.html" },
  ];
  return (
    <header className="nav">
      <div className="nav-inner">
        <a className="brand" href="UX4G Homepage.html">
          <div className="brand-mark">U4</div>
          <div className="brand-text">
            <div className="row">
              <span className="wordmark">UX4G</span>
              <span className="sub">Design System</span>
            </div>
            <span className="gov">A Government of India Initiative</span>
          </div>
        </a>
        <nav className="nav-links">
          {links.map((x) => (
            <a key={x.l}
               className={"nav-link" + ("Foundations" === x.l ? " active" : "")}
               href={x.href}
            >{x.l}</a>
          ))}
        </nav>
        <a className="btn btn-primary" href="UX4G Homepage.html">← Home</a>
      </div>
    </header>
  );
}

/* Foundation previews */
function PColor() {
  const ramp = ["#EFEBFF", "#D3C6FF", "#A78FFF", "#7A5DFF", "#6A4EFF", "#4A2BC2", "#301C7D"];
  return (
    <div className="fp-color">
      {ramp.map((c, i) => <div key={i} className="swatch" style={{ background: c }}></div>)}
      <div className="swatch" style={{ background: "#FFA827", marginLeft: 6, borderRadius: 6 }}></div>
    </div>
  );
}
function PType() {
  return (
    <div className="fp-type">
      <span className="sz-1">अ Aa</span>
      <span className="sz-2">अ Aa</span>
      <span className="sz-3">அ Aa</span>
    </div>
  );
}
function PSpace() {
  return (
    <div className="fp-space">
      <div className="blk"></div>
      <div className="blk"></div>
      <div className="blk"></div>
      <div className="blk"></div>
      <div className="blk"></div>
    </div>
  );
}
function PLayout() {
  const make = (n) => Array.from({ length: n }).map((_, i) => <i key={i}></i>);
  return (
    <div className="fp-layout">
      <div className="gp">
        <div className="gp-cols c4">{make(4)}</div>
        <div className="gp-cap">Mobile · 4</div>
      </div>
      <div className="gp">
        <div className="gp-cols c8">{make(8)}</div>
        <div className="gp-cap">Tablet · 8</div>
      </div>
      <div className="gp">
        <div className="gp-cols c12">{make(12)}</div>
        <div className="gp-cap">Desktop · 12</div>
      </div>
    </div>
  );
}
function PElev() {
  return (
    <div className="fp-elev">
      <div className="layer e1"></div>
      <div className="layer e2"></div>
      <div className="layer e3"></div>
    </div>
  );
}
function PRadius() {
  return (
    <div className="fp-radius">
      <div className="rb r0"></div>
      <div className="rb r2"></div>
      <div className="rb r4"></div>
      <div className="rb r8"></div>
      <div className="rb r16"></div>
    </div>
  );
}

const FOUNDATIONS = [
  { num: "F-01", name: "Colour",          desc: "Primary, semantic, and neutral palettes. Includes contrast ratios and token names.",          Preview: PColor },
  { num: "F-02", name: "Typography",      desc: "Type scale, weights, and line heights across 22 Indian languages.",                            Preview: PType  },
  { num: "F-03", name: "Spacing",         desc: "A base-4 spacing scale used across all components and layouts.",                                Preview: PSpace },
  { num: "F-04", name: "Layout",          desc: "Grid system, breakpoints, and container widths for mobile, tablet, and desktop.",              Preview: PLayout },
  { num: "F-05", name: "Elevation",       desc: "Shadow levels that communicate hierarchy and depth.",                                           Preview: PElev },
  { num: "F-06", name: "Borders & Radius",desc: "Border widths and corner radius values across component types.",                               Preview: PRadius },
];

const PRINCIPLES = [
  { n: "01", name: "Accessibility first",     desc: "WCAG 2.1 AA by default across every foundation decision." },
  { n: "02", name: "Multilingual by design",  desc: "Every scale and spacing works across Devanagari, Tamil, Telugu, and 19 other scripts." },
  { n: "03", name: "Consistent and token-driven", desc: "Every value is a named token, not a magic number." },
  { n: "04", name: "Government-appropriate",  desc: "Calm, clear, trustworthy, not playful or decorative.", amber: true },
];

function App() {
  const { toasts, push } = useToasts();
  const stub = (n) => push(`${n}, page coming soon`);

  return (
    <>
      <Navbar onStub={stub} />
      <main className="fnd-page">
        <section className="fnd-header">
          <div className="container">
            <div className="fnd-crumb">
              <a href="UX4G Homepage.html">Home</a>
              <span className="sep">/</span>
              <span className="current">Foundations</span>
            </div>
            <h1 className="fnd-h">Foundations</h1>
            <p className="fnd-desc">
              The shared visual language behind every UX4G component. Colour, typography, spacing, and structure, defined once, applied everywhere.
            </p>
          </div>
        </section>

        <section className="fnd-grid-wrap">
          <div className="container">
            <div className="fnd-grid">
              {FOUNDATIONS.map(({ num, name, desc, Preview }) => (
                <div key={num} className="fnd-card" onClick={() => stub(name)}>
                  <div className="fc-preview"><Preview /></div>
                  <div className="fc-num">{num}</div>
                  <h3 className="fc-name">{name}</h3>
                  <p className="fc-desc">{desc}</p>
                  <span className="fc-arrow">Open foundation ↗</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="principles">
          <div className="container">
            <h2 className="pr-head">What guides every decision</h2>
            <div className="pr-row">
              {PRINCIPLES.map((p) => (
                <div key={p.n} className={"pr-item" + (p.amber ? " amber" : "")}>
                  <div className="pr-glyph">PRINCIPLE · {p.n}</div>
                  <h3 className="pr-name">{p.name}</h3>
                  <div className="pr-rule"></div>
                  <p className="pr-desc">{p.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Toasts items={toasts} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
