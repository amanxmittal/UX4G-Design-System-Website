/* global React, ReactDOM */
const { useState, useEffect, useRef, useCallback } = React;

/* ───────────────── Toasts + Nav (shared) ───────────────── */
function useToasts() {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2400);
  }, []);
  return { toasts, push };
}
function Toasts({ items }) {
  return (
    <div className="toast-stack">
      {items.map((t) => (
        <div className="toast" key={t.id}>
          <span className="t-mark">i</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}
function Navbar({ onStub }) {
  const links = [
    { l: "Foundations", href: "UX4G Foundations.html" },
    { l: "Fundamentals", href: "UX4G Fundamentals.html" },
    { l: "Components", href: "UX4G Components.html" },
    { l: "Patterns", href: "UX4G Patterns.html" },
  ];
  return (
    <header className="nav">
      <div className="nav-inner">
        <a className="brand" href="UX4G Homepage.html">
          <div className="brand-mark">U4</div>
          <div className="brand-text">
            <div className="row">
              <span className="wordmark">UX4G</span>
              <span className="sub">Design System</span>
            </div>
            <span className="gov">A Government of India Initiative</span>
          </div>
        </a>
        <nav className="nav-links">
          {links.map((x) => (
            <a key={x.l}
               className={"nav-link" + (x.l === "Components" ? " active" : "")}
               href={x.href}
            >{x.l}</a>
          ))}
        </nav>
        <a className="btn btn-primary" href="UX4G Homepage.html">← Home</a>
      </div>
    </header>
  );
}

/* ───────────────── Reusable Button (real) ───────────────── */
function Btn({ kind = "primary", size = "m", state, iconLeft, iconRight, loading, children, onClick }) {
  const cls = ["btn-" + kind + "-real", "btn-" + size];
  if (state) cls.push("state-" + state);
  if (loading) cls.push("state-loading");
  return (
    <button className={cls.join(" ")} disabled={state === "disabled"} onClick={onClick} type="button">
      {loading && <span className="spin"></span>}
      {iconLeft && !loading && <span className="btn-ico">{iconLeft}</span>}
      <span>{children}</span>
      {iconRight && <span className="btn-ico">{iconRight}</span>}
    </button>
  );
}

/* ───────────────── Sidebar ───────────────── */
const SECTIONS = [
  { id: "overview", label: "Overview" },
  { id: "variants", label: "Variants & States" },
  { id: "when", label: "When to use" },
  { id: "dos", label: "Do's & Don'ts" },
  { id: "a11y", label: "Accessibility notes" },
  { id: "related", label: "Related components" },
];
function Sidebar({ active, onStub }) {
  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 100;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };
  return (
    <aside className="cd-side">
      <div className="side-label">On this page</div>
      <ul>
        {SECTIONS.map((s) => (
          <li key={s.id}>
            <a
              className={active === s.id ? "active" : ""}
              onClick={() => scrollTo(s.id)}
            >{s.label}</a>
          </li>
        ))}
        <li><div className="divider"></div></li>
        <li>
          <a className="ext" onClick={() => onStub("Storybook · Button")}>View in Storybook</a>
        </li>
      </ul>
    </aside>
  );
}

/* ───────────────── Sections ───────────────── */
function HeaderSec({ onStub }) {
  return (
    <div className="cd-header">
      <div className="cd-crumb">
        <a onClick={() => onStub("Home")}>Home</a>
        <span className="sep">/</span>
        <a href="UX4G Components.html">Components</a>
        <span className="sep">/</span>
        <a onClick={() => onStub("Form Elements")}>Form Elements</a>
        <span className="sep">/</span>
        <span className="current">Button</span>
      </div>
      <div className="cd-title-row">
        <h1 className="cd-title">Button</h1>
        <span className="cd-chip">Form Elements</span>
        <span className="cd-status"><span className="ld"></span>Live</span>
      </div>
      <p className="cd-desc">
        Triggers actions. Use for form submissions, navigation confirmations, and primary user decisions.
      </p>
    </div>
  );
}

function Overview() {
  return (
    <section id="overview" className="cd-section">
      <div className="cd-section-num">01 / OVERVIEW</div>
      <h2 className="cd-section-title">Overview</h2>
      <p className="cd-section-lede">
        Every variant below is rendered live with the UX4G token set, same code that ships in services. Use this as the visual reference when choosing the right button.
      </p>
      <div className="show-stage">
        <div className="show-row">
          <div className="row-label">By type<div className="line"></div></div>
          <div className="row-items">
            <div className="row-item"><Btn kind="primary">Submit application</Btn><span className="it-cap">Primary</span></div>
            <div className="row-item"><Btn kind="secondary">Save draft</Btn><span className="it-cap">Secondary</span></div>
            <div className="row-item"><Btn kind="ghost">Cancel</Btn><span className="it-cap">Ghost</span></div>
            <div className="row-item"><Btn kind="tertiary">Skip for now</Btn><span className="it-cap">Tertiary</span></div>
            <div className="row-item"><Btn kind="destructive">Discard application</Btn><span className="it-cap">Destructive</span></div>
            <div className="row-item"><Btn kind="link">Learn more →</Btn><span className="it-cap">Link-style</span></div>
          </div>
        </div>

        <div className="show-row">
          <div className="row-label">By state<div className="line"></div></div>
          <div className="row-items">
            <div className="row-item"><Btn kind="primary">Verify identity</Btn><span className="it-cap">Default</span></div>
            <div className="row-item"><Btn kind="primary" state="hover">Verify identity</Btn><span className="it-cap">Hover</span></div>
            <div className="row-item"><Btn kind="primary" state="focus">Verify identity</Btn><span className="it-cap">Focused</span></div>
            <div className="row-item"><Btn kind="primary" state="disabled">Verify identity</Btn><span className="it-cap">Disabled</span></div>
            <div className="row-item"><Btn kind="primary" loading>Verifying…</Btn><span className="it-cap">Loading</span></div>
            <div className="row-item"><Btn kind="primary" iconLeft="+">Add document</Btn><span className="it-cap">Icon left</span></div>
            <div className="row-item"><Btn kind="primary" iconRight="→">Continue</Btn><span className="it-cap">Icon right</span></div>
          </div>
        </div>

        <div className="show-row">
          <div className="row-label">By size<div className="line"></div></div>
          <div className="row-items">
            <div className="row-item"><Btn kind="primary" size="s">Small button</Btn><span className="it-cap">Small · 28px</span></div>
            <div className="row-item"><Btn kind="primary" size="m">Medium button</Btn><span className="it-cap">Medium · 40px</span></div>
            <div className="row-item"><Btn kind="primary" size="l">Large button</Btn><span className="it-cap">Large · 48px</span></div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Variants() {
  const list = [
    { num: "T-01", name: "Primary",     kind: "primary",     label: "Submit application", note: "For the single most important action on a screen, Submit application, Verify identity." },
    { num: "T-02", name: "Secondary",   kind: "secondary",   label: "Save draft", note: "For supporting actions that aren't the primary goal, Save draft, Go back." },
    { num: "T-03", name: "Ghost",       kind: "ghost",       label: "Cancel", note: "For low-emphasis actions, Cancel, Skip, Learn more. Pairs alongside a primary button." },
    { num: "T-04", name: "Destructive", kind: "destructive", label: "Discard draft", note: "For irreversible actions, Delete, Discard, Revoke. Always pair with a confirmation modal." },
  ];
  return (
    <section id="variants" className="cd-section">
      <div className="cd-section-num">02 / VARIANTS & STATES</div>
      <h2 className="cd-section-title">Variants & states</h2>
      <p className="cd-section-lede">
        Choose by emphasis, not aesthetic. A screen should have at most one primary button; everything else supports it.
      </p>
      <div className="variant-grid">
        {list.map((v) => (
          <div className="variant-card" key={v.num}>
            <div className="stage"><Btn kind={v.kind} size="l">{v.label}</Btn></div>
            <div>
              <div className="v-head"><span className="num">{v.num}</span>·<span>{v.name}</span></div>
              <h3 className="v-name">{v.name}</h3>
              <p className="v-text">{v.note}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="loading-callout">
        <div className="lc-spin"></div>
        <div className="lc-body">
          <strong>On the loading state, </strong>always show a spinner with the original label during async operations.
          Never hide the label or swap it for "Loading…", citizens lose track of which action they triggered.
        </div>
      </div>
    </section>
  );
}

function When() {
  const yes = [
    "The action submits a form or confirms a decision.",
    "The action is the primary goal of the current screen.",
    "You need to communicate different levels of priority between actions.",
  ];
  const no = [
    "Navigation between pages, use a Link instead.",
    "More than 3 buttons on one screen, reconsider the information hierarchy.",
    "Actions inside a table row, use a text link or icon button instead.",
  ];
  return (
    <section id="when" className="cd-section">
      <div className="cd-section-num">03 / WHEN TO USE</div>
      <h2 className="cd-section-title">When to use</h2>
      <div className="use-grid">
        <div className="use-col yes">
          <span className="uc-tag">✓ When to use</span>
          <h3>Reach for a button</h3>
          <ul>
            {yes.map((t, i) => (<li key={i}><span className="glyph">✓</span>{t}</li>))}
          </ul>
        </div>
        <div className="use-col no">
          <span className="uc-tag">✕ When not to use</span>
          <h3>Pick something else</h3>
          <ul>
            {no.map((t, i) => (<li key={i}><span className="glyph">✕</span>{t}</li>))}
          </ul>
        </div>
      </div>
    </section>
  );
}

function DosDonts() {
  return (
    <section id="dos" className="cd-section">
      <div className="cd-section-num">04 / DO's & DON'Ts</div>
      <h2 className="cd-section-title">Do's & Don'ts</h2>
      <p className="cd-section-lede">
        Every pair has a rendered example, look first, then read.
      </p>

      <div className="dd-pair">
        <div className="dd-card do">
          <div className="dd-label">✓ Do</div>
          <div className="dd-stage">
            <Btn kind="primary">Submit application</Btn>
            <Btn kind="ghost">Cancel</Btn>
          </div>
          <div className="dd-rule">One primary button per section, guides the eye to the next step.</div>
        </div>
        <div className="dd-card dont">
          <div className="dd-label">✕ Don't</div>
          <div className="dd-stage">
            <Btn kind="primary">Submit</Btn>
            <Btn kind="primary">Save</Btn>
            <Btn kind="primary">Continue</Btn>
          </div>
          <div className="dd-rule">Multiple primary buttons competing for attention, no clear next step.</div>
        </div>
      </div>

      <div className="dd-pair">
        <div className="dd-card do">
          <div className="dd-label">✓ Do</div>
          <div className="dd-stage">
            <Btn kind="primary">Submit application</Btn>
          </div>
          <div className="dd-rule">Label describes the action, predictable and trustworthy.</div>
        </div>
        <div className="dd-card dont">
          <div className="dd-label">✕ Don't</div>
          <div className="dd-stage">
            <Btn kind="primary">OK</Btn>
            <Btn kind="primary">Click here</Btn>
          </div>
          <div className="dd-rule">Vague labels, citizens can't predict what will happen.</div>
        </div>
      </div>

      <div className="dd-pair">
        <div className="dd-card do">
          <div className="dd-label">✓ Do</div>
          <div className="dd-stage">
            <Btn kind="primary" loading>Submitting…</Btn>
          </div>
          <div className="dd-rule">Show loading state during async action, confirms the system received the tap.</div>
        </div>
        <div className="dd-card dont">
          <div className="dd-label">✕ Don't</div>
          <div className="dd-stage">
            <Btn kind="primary" state="disabled">Submit</Btn>
          </div>
          <div className="dd-rule">Disable the button without explanation, citizens assume the page is broken.</div>
        </div>
      </div>
    </section>
  );
}

function A11y() {
  const items = [
    { t: "Tap targets are at least 44×44px.", b: "Important for thumb-first mobile use and motor accessibility, the minimum size applies even to small buttons." },
    { t: "Disabled buttons explain why they're disabled.", b: "Use a tooltip or helper text directly below, a button that does nothing without context feels broken." },
    { t: "Loading state announces progress.", b: "The spinner is paired with assistive-tech announcements so screen-reader users know the action is in flight, not stuck." },
    { t: "Destructive actions always require confirmation.", b: "Never immediate and irreversible, pair every destructive button with a Modal or Dialog asking the user to confirm." },
  ];
  return (
    <section id="a11y" className="cd-section">
      <div className="cd-section-num">05 / ACCESSIBILITY</div>
      <h2 className="cd-section-title">Accessibility notes</h2>
      <p className="cd-section-lede">
        For full WCAG mappings and aria implementation, see the Storybook entry. These are the rules every designer should hold in their head.
      </p>
      <div className="a11y-list">
        {items.map((it, i) => (
          <div className="a11y-row" key={i}>
            <div className="a-num">N° 0{i + 1}</div>
            <div className="a-body">
              <strong>{it.t}</strong>
              {it.b}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Related({ onStub }) {
  return (
    <section id="related" className="cd-section">
      <div className="cd-section-num">06 / RELATED</div>
      <h2 className="cd-section-title">Related components</h2>
      <div className="related-grid">
        <div className="related-card" onClick={() => onStub("Icon Button")}>
          <div className="r-stage">
            <div style={{ display: "flex", gap: 8 }}>
              <div style={{ width: 36, height: 36, borderRadius: 6, background: "var(--primary)", color: "#fff", display: "grid", placeItems: "center", fontFamily: "var(--font-mono)", fontWeight: 700 }}>+</div>
              <div style={{ width: 36, height: 36, borderRadius: 6, background: "#fff", border: "1px solid var(--gray-300)", color: "var(--ink)", display: "grid", placeItems: "center", fontFamily: "var(--font-mono)" }}>⌕</div>
            </div>
          </div>
          <h3 className="r-name">Icon Button</h3>
          <p className="r-note">When you need a button but have no space for a label.</p>
          <span className="r-arrow">↗</span>
        </div>
        <div className="related-card" onClick={() => onStub("Link")}>
          <div className="r-stage">
            <span style={{ color: "var(--primary)", fontWeight: 600, borderBottom: "1px solid var(--primary)", paddingBottom: 1, fontSize: 16 }}>View grievance status →</span>
          </div>
          <h3 className="r-name">Link</h3>
          <p className="r-note">When the action navigates rather than submits.</p>
          <span className="r-arrow">↗</span>
        </div>
        <div className="related-card" onClick={() => onStub("Modal")}>
          <div className="r-stage">
            <div style={{ background: "rgba(14,14,18,0.4)", padding: 10, borderRadius: 6, width: "100%", display: "grid", placeItems: "center" }}>
              <div style={{ background: "#fff", padding: 10, borderRadius: 5, width: "100%" }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: "var(--ink)" }}>Confirm submission</div>
                <div style={{ display: "flex", gap: 4, marginTop: 6, justifyContent: "flex-end" }}>
                  <span style={{ padding: "3px 7px", fontSize: 9.5, color: "var(--gray-700)" }}>Cancel</span>
                  <span style={{ padding: "3px 7px", fontSize: 9.5, background: "var(--primary)", color: "#fff", borderRadius: 3, fontWeight: 600 }}>Submit</span>
                </div>
              </div>
            </div>
          </div>
          <h3 className="r-name">Modal</h3>
          <p className="r-note">Pair with Destructive buttons for confirmation flows.</p>
          <span className="r-arrow">↗</span>
        </div>
      </div>

      <div className="sb-cta">
        <div className="sb-text">
          <strong>Building with UX4G?</strong> See the Button's full API reference, props, code examples, and accessibility implementation in Storybook.
        </div>
        <a className="sb-link" onClick={() => onStub("Storybook · Button")}>Open in Storybook ↗</a>
      </div>
    </section>
  );
}

/* ───────────────── App ───────────────── */
function App() {
  const { toasts, push } = useToasts();
  const stub = (n) => push(`${n}, page coming soon`);
  const [active, setActive] = useState("overview");

  useEffect(() => {
    const onScroll = () => {
      const probe = 180;
      let cur = SECTIONS[0].id;
      for (const s of SECTIONS) {
        const el = document.getElementById(s.id);
        if (!el) continue;
        const top = el.getBoundingClientRect().top;
        if (top < probe) cur = s.id;
      }
      setActive(cur);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <Navbar onStub={stub} />
      <main className="cd-page">
        <div className="cd-layout">
          <div className="cd-main">
            <HeaderSec onStub={stub} />
            <Overview />
            <Variants />
            <When />
            <DosDonts />
            <A11y />
            <Related onStub={stub} />
          </div>
          <Sidebar active={active} onStub={stub} />
        </div>
      </main>
      <Toasts items={toasts} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
