/* global React, ReactDOM */
const { useState, useCallback } = React;

function useToasts() {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2400);
  }, []);
  return { toasts, push };
}
function Toasts({ items }) {
  return (
    <div className="toast-stack">
      {items.map((t) => (
        <div className="toast" key={t.id}>
          <span className="t-mark">i</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}
function Navbar({ onStub }) {
  const links = [
    { l: "Foundations", href: "UX4G Foundations.html" },
    { l: "Fundamentals", href: "UX4G Fundamentals.html" },
    { l: "Components", href: "UX4G Components.html" },
    { l: "Patterns", href: "UX4G Patterns.html" },
  ];
  return (
    <header className="nav">
      <div className="nav-inner">
        <a className="brand" href="UX4G Homepage.html">
          <div className="brand-mark">U4</div>
          <div className="brand-text">
            <div className="row">
              <span className="wordmark">UX4G</span>
              <span className="sub">Design System</span>
            </div>
            <span className="gov">A Government of India Initiative</span>
          </div>
        </a>
        <nav className="nav-links">
          {links.map((x) => (
            <a key={x.l}
               className={"nav-link" + ("Patterns" === x.l ? " active" : "")}
               href={x.href}
            >{x.l}</a>
          ))}
        </nav>
        <a className="btn btn-primary" href="UX4G Homepage.html">← Home</a>
      </div>
    </header>
  );
}

const GROUPS = [
  { num: "P-01", name: "Identity & Access", live: true,
    desc: "Sign in, sign up, OTP verification, session management, account recovery, and authentication error states.",
    count: "6 patterns" },
  { num: "P-02", name: "Consent & Declaration", live: false,
    desc: "Data consent flows, DPDP-compliant disclosures, and declaration before submission.",
    count: "In design" },
  { num: "P-03", name: "Application & Submission", live: false,
    desc: "Eligibility checks, form journeys, document upload, and acknowledgement flows.",
    count: "In design" },
  { num: "P-04", name: "Status & Tracking", live: false,
    desc: "Application status, grievance tracking, and SLA visibility for citizens.",
    count: "In design" },
  { num: "P-05", name: "Payment & Transactions", live: false,
    desc: "Fee payment, receipts, and waiver flows for government services.",
    count: "In design" },
  { num: "P-06", name: "Notifications", live: false,
    desc: "SMS, email, in-app, and reminder sequences for service updates.",
    count: "In design" },
  { num: "P-07", name: "Feedback & Communication", live: false,
    desc: "Post-service ratings, inline guidance, and contact support flows.",
    count: "In design" },
];

const CONTAINS = [
  { g: "01", n: "Screen flows",        d: "The complete sequence of screens a citizen moves through, end to end." },
  { g: "02", n: "Component references", d: "Which UX4G components make up each screen, drop-in ready, not redrawn." },
  { g: "03", n: "Edge cases",          d: "How to handle errors, timeouts, offline states, and authentication failures." },
  { g: "04", n: "Do's & Don'ts",       d: "What to replicate from the pattern, and what to avoid when adapting it." },
];

function App() {
  const { toasts, push } = useToasts();
  const stub = (n) => push(`${n}, page coming soon`);

  return (
    <>
      <Navbar onStub={stub} />
      <main className="pt-page">
        <section className="pt-header">
          <div className="container">
            <div className="pt-crumb">
              <a href="UX4G Homepage.html">Home</a>
              <span className="sep">/</span>
              <span className="current">Patterns</span>
            </div>
            <h1 className="pt-h">Patterns</h1>
            <p className="pt-desc">
              Patterns combine components into proven solutions for recurring government service challenges. Use them to design consistent citizen journeys without starting from scratch.
            </p>
          </div>
        </section>

        <section className="pt-explainer">
          <div className="container">
            <div className="row">
              <div className="cell">
                <span className="cap">Layer 1</span>
                <span className="nm">Foundations</span>
                <span className="sub">Visual rules</span>
              </div>
              <div className="arrow">→</div>
              <div className="cell">
                <span className="cap">Layer 2</span>
                <span className="nm">Components</span>
                <span className="sub">Building blocks</span>
              </div>
              <div className="arrow">→</div>
              <div className="cell active">
                <span className="cap">You are here</span>
                <span className="nm">Patterns</span>
                <span className="sub">Composed solutions</span>
              </div>
            </div>
          </div>
        </section>

        <section className="pt-grid-wrap">
          <div className="container">
            <div className="pt-grid">
              {GROUPS.map((g) => (
                <div key={g.num} className={"pcard " + (g.live ? "live" : "soon")}
                     onClick={() => g.live ? stub(g.name) : null}>
                  <div className="pc-top">
                    <span className="pc-num">{g.num}</span>
                    {g.live
                      ? <span className="pc-status live"><span className="ld"></span>Live</span>
                      : <span className="pc-status soon">Coming soon</span>}
                  </div>
                  <h3 className="pc-name">{g.name}</h3>
                  <p className="pc-desc">{g.desc}</p>
                  <div className="pc-foot">
                    <span className="pc-count">{g.count}</span>
                    {g.live
                      ? <span className="pc-link">View patterns →</span>
                      : <span className="pc-link">Not yet available</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="pt-contains">
          <div className="container">
            <h2>What you get with each pattern</h2>
            <div className="grid">
              {CONTAINS.map((c) => (
                <div key={c.g} className="item">
                  <div className="glyph">N° {c.g}</div>
                  <h3 className="nm">{c.n}</h3>
                  <p className="ds">{c.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Toasts items={toasts} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
