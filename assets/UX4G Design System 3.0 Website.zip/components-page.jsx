/* global React, ReactDOM */
const { useState, useEffect, useRef, useCallback } = React;

/* ───────────────── Toast ───────────────── */
function useToasts() {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2400);
  }, []);
  return { toasts, push };
}
function Toasts({ items }) {
  return (
    <div className="toast-stack">
      {items.map((t) => (
        <div className="toast" key={t.id}>
          <span className="t-mark">i</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

/* ───────────────── Navbar (shared) ───────────────── */
function Navbar({ onStub, onExplore, active }) {
  const links = [
    { l: "Foundations", href: "UX4G Foundations.html" },
    { l: "Fundamentals", href: "UX4G Fundamentals.html" },
    { l: "Components", href: "UX4G Components.html" },
    { l: "Patterns", href: "UX4G Patterns.html" },
  ];
  return (
    <header className="nav">
      <div className="nav-inner">
        <a className="brand" href="UX4G Homepage.html">
          <div className="brand-mark">U4</div>
          <div className="brand-text">
            <div className="row">
              <span className="wordmark">UX4G</span>
              <span className="sub">Design System</span>
            </div>
            <span className="gov">A Government of India Initiative</span>
          </div>
        </a>
        <nav className="nav-links">
          {links.map((x) => (
            <a
              key={x.l}
              className={"nav-link" + ("Components" === x.l ? " active" : "")}
              href={x.href}
            >
              {x.l}
            </a>
          ))}
        </nav>
        <a className="btn btn-primary" href="UX4G Homepage.html">
          ← Home
        </a>
      </div>
    </header>
  );
}

/* ───────────────── Component previews ───────────────── */
const Previews = {
  Button: () => (
    <div className="pv-row">
      <div className="pv-btn">Submit application <span style={{ opacity: 0.7 }}>→</span></div>
      <div className="pv-btn ghost">Cancel</div>
    </div>
  ),
  Link: () => <span className="pv-link">View grievance status →</span>,
  Input: () => <div className="pv-input focus">+91 98765 43210</div>,
  Textarea: () => (
    <div className="pv-textarea">
      Briefly describe the issue you faced with the service…
    </div>
  ),
  Checkbox: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <div className="pv-check"><div className="pv-check-box">✓</div>I consent under DPDP Act 2023</div>
      <div className="pv-check"><div className="pv-check-box un"></div>Send SMS updates</div>
    </div>
  ),
  Radio: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <div className="pv-radio"><div className="pv-radio-ring"></div>Aadhaar OTP</div>
      <div className="pv-radio"><div className="pv-radio-ring un"></div>DigiLocker SSO</div>
    </div>
  ),
  Toggle: () => (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <div className="pv-toggle"></div>
      <span style={{ fontSize: 13, color: "var(--ink)" }}>High-contrast</span>
    </div>
  ),
  Dropdown: () => (
    <div className="pv-dropdown">
      <span>English (en-IN)</span>
      <span className="ca">▾</span>
    </div>
  ),
  Combobox: () => (
    <div className="pv-combo">
      <div className="top"><span>District…</span><span style={{ color: "var(--gray-500)" }}>▾</span></div>
      <div className="opt hl">Ahmedabad</div>
      <div className="opt">Anand</div>
    </div>
  ),
  Search: () => (
    <div className="pv-search">
      <span className="ic">⌕</span>
      <span>Search 55+ components</span>
    </div>
  ),
  Slider: () => (
    <div className="pv-slider">
      <div className="track">
        <div className="fill"></div>
        <div className="knob"></div>
      </div>
      <div className="vals"><span>0</span><span>62</span><span>100</span></div>
    </div>
  ),
  FormFieldGroup: () => (
    <div className="pv-fg">
      <div className="pv-fg-label">Aadhaar number</div>
      <div className="pv-fg-input">XXXX XXXX 4271</div>
      <div className="pv-fg-help">12 digits · verified</div>
    </div>
  ),
  OTP: () => (
    <div className="pv-otp">
      {["4", "8", "3", "7", "", ""].map((v, i) => (
        <div key={i} className={"pv-otp-cell" + (v ? " f" : "") + (i === 4 ? " active" : "")}>{v}</div>
      ))}
    </div>
  ),
  DatePicker: () => (
    <div className="pv-date">
      <span className="cal">▤</span>
      <span>28 / 04 / 2026</span>
    </div>
  ),
  FileUpload: () => (
    <div className="pv-upload">
      <div className="ic-box">PDF</div>
      <div>
        <div className="lbl">aadhaar-card.pdf</div>
        <div className="sb">312 KB · UPLOADED</div>
      </div>
    </div>
  ),
  AutoComplete: () => (
    <div className="pv-ac">
      <div className="ip">Anjali Bha<em>|</em></div>
      <div className="opt"><strong>Anjali Bha</strong>ttacharya</div>
      <div className="opt"><strong>Anjali Bha</strong>radwaj</div>
    </div>
  ),

  AlertToast: () => (
    <div className="pv-alert">
      <div className="pa-icon">✓</div>
      <div>
        <div className="pa-title">Application submitted</div>
        <div>Reference AP-2026-DM-83942</div>
      </div>
    </div>
  ),
  Progress: () => (
    <div className="pv-prog">
      <div className="track"><div className="fill"></div></div>
      <div className="meta"><span>STEP 4 OF 6</span><span>68%</span></div>
    </div>
  ),
  Rating: () => (
    <div style={{ textAlign: "center" }}>
      <div className="pv-rate">
        <span className="star">★</span><span className="star">★</span><span className="star">★</span><span className="star">★</span><span className="star dim">★</span>
      </div>
      <div style={{ fontSize: 11, color: "var(--gray-500)", fontFamily: "var(--font-mono)", marginTop: 6, letterSpacing: "0.04em" }}>4.2 · 1,284 RESPONSES</div>
    </div>
  ),
  DraftBanner: () => (
    <div className="pv-draft">
      <span className="ti">Draft saved</span>
      <span className="sb">2 MIN AGO</span>
    </div>
  ),
  SLAProgress: () => (
    <div className="pv-sla">
      <div className="head"><span>Income certificate</span><span className="rem">18d left</span></div>
      <div className="bar"><div className="seg"></div></div>
    </div>
  ),
  Spinner: () => <div className="pv-spinner"></div>,

  Badge: () => (
    <span className="pv-badge"><span className="b-dot"></span>Under review</span>
  ),
  Tag: () => (
    <div style={{ display: "flex", gap: 6 }}>
      <span className="pv-tag">DPDP 2023 <span className="x">×</span></span>
      <span className="pv-tag">v3.0 <span className="x">×</span></span>
    </div>
  ),
  Chip: () => (
    <div style={{ display: "flex", gap: 6 }}>
      <span className="pv-chip on">All</span>
      <span className="pv-chip">Live</span>
      <span className="pv-chip">Coming</span>
    </div>
  ),
  Card: () => (
    <div className="pv-card">
      <div className="ti">Income Certificate</div>
      <div className="sb">Issued by SDM office</div>
      <div className="meta">
        <span className="pv-badge" style={{ background: "#EBF6EF", color: "var(--success)", borderColor: "#B9DDC5" }}><span className="b-dot"></span>Verified</span>
      </div>
    </div>
  ),
  Table: () => (
    <div className="pv-table">
      <div className="h"><span>Service</span><span>Status</span><span>SLA</span></div>
      <div className="r"><span>Income cert.</span><span className="ok">Verified</span><span>18d</span></div>
      <div className="r"><span>PAN update</span><span className="ok">Active</span><span>4d</span></div>
    </div>
  ),
  Accordion: () => (
    <div className="pv-acc">
      <div className="row open">Required documents <span className="ic">−</span></div>
      <div className="row">Eligibility criteria <span className="ic">+</span></div>
      <div className="row">Processing time <span className="ic">+</span></div>
    </div>
  ),
  Carousel: () => (
    <div>
      <div className="pv-carousel">
        <div className="slide"></div>
        <div className="slide main"></div>
        <div className="slide"></div>
      </div>
      <div className="pv-carousel" style={{ marginTop: 0 }}>
        <div className="dots" style={{ margin: "8px auto 0" }}>
          <span className="d"></span><span className="d on"></span><span className="d"></span><span className="d"></span>
        </div>
      </div>
    </div>
  ),
  EmptyState: () => (
    <div className="pv-empty">
      <div className="box">∅</div>
      <div className="lbl">No applications yet</div>
    </div>
  ),
  StatusPipeline: () => (
    <div className="pv-pipe">
      <div className="line"><div className="pg"></div></div>
      <div className="row">
        <div className="node done">✓</div>
        <div className="node done">✓</div>
        <div className="node active">3</div>
        <div className="node">4</div>
      </div>
      <div className="labels">
        <span>FILED</span><span>ACK</span><span>VERIFY</span><span>ISSUE</span>
      </div>
    </div>
  ),
  EscalationTree: () => (
    <div className="pv-tree">
      <div className="item lv1">Citizen complaint</div>
      <div className="item l2 active"><span className="tw">└</span>SDM office (Lv. 1)</div>
      <div className="item l3"><span className="tw">└</span>DM office (Lv. 2)</div>
      <div className="item l3"><span className="tw">└</span>Commissioner (Lv. 3)</div>
    </div>
  ),
  JourneyTimeline: () => (
    <div className="pv-jt">
      <div className="step">
        <div className="marker"><div className="dot"></div><div className="ln done"></div></div>
        <div className="info"><div className="ti">Application filed</div><div className="meta">14 APR · 09:24</div></div>
      </div>
      <div className="step">
        <div className="marker"><div className="dot act"></div><div className="ln"></div></div>
        <div className="info"><div className="ti">Field verification</div><div className="meta">IN PROGRESS</div></div>
      </div>
      <div className="step">
        <div className="marker"><div className="dot pen"></div></div>
        <div className="info"><div className="ti">Certificate issued</div><div className="meta">PENDING</div></div>
      </div>
    </div>
  ),
  Checklist: () => (
    <div className="pv-checklist">
      <div className="pv-cl-row done"><div className="b">✓</div>Aadhaar verified</div>
      <div className="pv-cl-row done"><div className="b">✓</div>Address proof uploaded</div>
      <div className="pv-cl-row"><div className="b"></div>Photograph attached</div>
      <div className="pv-cl-row"><div className="b"></div>Application fee paid</div>
    </div>
  ),
  SlotGrid: () => (
    <div className="pv-slots">
      <div className="slot">09:00</div>
      <div className="slot full">10:00</div>
      <div className="slot on">11:00</div>
      <div className="slot">12:00</div>
      <div className="slot">14:00</div>
      <div className="slot">15:00</div>
    </div>
  ),
  ChipGroup: () => (
    <div className="pv-chip-group">
      <span className="pv-chip on">All services</span>
      <span className="pv-chip">Identity</span>
      <span className="pv-chip">Property</span>
      <span className="pv-chip">Welfare</span>
    </div>
  ),
  ResultListRow: () => (
    <div className="pv-rl">
      <div className="ti">Pan card correction · ITD</div>
      <div className="meta"><span>FILED 12 APR</span><span className="ok">● ACTIVE</span></div>
    </div>
  ),
  ReceiptCard: () => (
    <div className="pv-receipt">
      <div className="hdr">Receipt · RCT-89234</div>
      <div className="amt">₹50.00</div>
      <div className="sb">Property tax · Q4 FY26</div>
      <div className="seal">PAID</div>
    </div>
  ),
  List: () => (
    <div className="pv-list">
      <div className="item"><div className="av">AB</div>Anjali Bhattacharya</div>
      <div className="item"><div className="av">VR</div>Vikram Reddy</div>
      <div className="item"><div className="av">PJ</div>Priya Joshi</div>
    </div>
  ),
  Pagination: () => (
    <div className="pv-pag">
      <div className="pg-btn arr">‹</div>
      <div className="pg-btn">1</div>
      <div className="pg-btn on">2</div>
      <div className="pg-btn">3</div>
      <span className="ellipsis">…</span>
      <div className="pg-btn">9</div>
      <div className="pg-btn arr">›</div>
    </div>
  ),
  Stepper: () => (
    <div className="pv-stepper">
      <div className="num done">✓</div>
      <div className="conn done"></div>
      <div className="num active">2</div>
      <div className="conn"></div>
      <div className="num">3</div>
      <div className="conn"></div>
      <div className="num">4</div>
    </div>
  ),
  Tab: () => (
    <div className="pv-tabs-c">
      <div className="t on">Overview</div>
      <div className="t">Documents</div>
      <div className="t">History</div>
    </div>
  ),

  Biometric: () => (
    <div className="pv-bio">
      <span className="corner tl"></span><span className="corner tr"></span>
      <span className="corner bl"></span><span className="corner br"></span>
      <span className="glyph">⌘</span>
    </div>
  ),
  DigiLocker: () => (
    <div className="pv-dl">
      <div className="sq">DL</div>
      <div>
        <div className="ti">Add to DigiLocker</div>
        <div className="sb">SECURE · GOVT VERIFIED</div>
      </div>
    </div>
  ),
  CalendarEvent: () => (
    <div className="pv-cal">
      <div className="row">
        <div className="day">
          <span className="m">MAY</span>
          <span className="d">12</span>
        </div>
        <div className="info">
          <div className="ti">Verification appointment</div>
          <div className="sb">10:30, 11:00 IST</div>
        </div>
      </div>
    </div>
  ),
  Payment: () => (
    <div className="pv-pay">
      <div className="head"><span>PROPERTY TAX</span><span>₹</span></div>
      <div className="amt">₹2,450</div>
      <div className="opts">
        <span className="o on">UPI</span>
        <span className="o">CARD</span>
        <span className="o">NB</span>
      </div>
    </div>
  ),
  Chart: () => (
    <div className="pv-chart">
      <div className="bar muted" style={{ height: "30%" }}></div>
      <div className="bar muted" style={{ height: "45%" }}></div>
      <div className="bar" style={{ height: "62%" }}></div>
      <div className="bar" style={{ height: "80%" }}></div>
      <div className="bar amber" style={{ height: "92%" }}></div>
      <div className="bar muted" style={{ height: "55%" }}></div>
    </div>
  ),
  Scheduler: () => (
    <div className="pv-sched">
      <div className="top">MAY 2026</div>
      <div className="grid">
        {["S","M","T","W","T","F","S"].map((d, i) => (
          <div key={"h"+i} className="c muted">{d}</div>
        ))}
        <div className="c muted">28</div><div className="c muted">29</div><div className="c muted">30</div>
        <div className="c">1</div><div className="c">2</div><div className="c">3</div><div className="c">4</div>
        <div className="c">5</div><div className="c dot">6</div><div className="c">7</div>
        <div className="c">8</div><div className="c on">9</div><div className="c">10</div><div className="c">11</div>
      </div>
    </div>
  ),
  Segmented: () => (
    <div className="pv-seg">
      <span className="s on">Today</span>
      <span className="s">Week</span>
      <span className="s">Month</span>
    </div>
  ),

  Navbar: () => (
    <div className="pv-nav">
      <span className="lg">UX4G</span>
      <div className="nv">
        <span>FND</span><span className="on">COMP</span><span>PAT</span>
      </div>
    </div>
  ),
  Footer: () => (
    <div className="pv-foot">
      <div className="wm">UX4G</div>
      <div className="tri"><span className="s"></span><span className="w"></span><span className="g"></span></div>
      <div className="cp">© 2026 · NEGD · MEITY</div>
    </div>
  ),
  Breadcrumb: () => (
    <div className="pv-bc">
      <span>Services</span>
      <span className="s">›</span>
      <span>Identity</span>
      <span className="s">›</span>
      <span className="cur">Aadhaar</span>
    </div>
  ),
  Divider: () => (
    <div className="pv-div">
      <div className="l"></div>
      <div className="lbl">OR CONTINUE WITH</div>
      <div className="l"></div>
    </div>
  ),
  Avatar: () => (
    <div className="pv-av-row">
      <div className="pv-av a1">AB</div>
      <div className="pv-av a2">VR</div>
      <div className="pv-av a3">PJ</div>
      <div className="pv-av a4">+6</div>
    </div>
  ),
  Image: () => <div className="pv-img">DOCUMENT SCAN</div>,
  IconButton: () => (
    <div className="pv-iconbtn-row">
      <div className="pv-iconbtn solid">+</div>
      <div className="pv-iconbtn">⌕</div>
      <div className="pv-iconbtn">⌥</div>
      <div className="pv-iconbtn">⌘</div>
    </div>
  ),
  Modal: () => (
    <div className="pv-modal-wrap">
      <div className="pv-modal">
        <div className="ti">Confirm submission</div>
        <div className="sb">Once submitted, this application cannot be edited.</div>
        <div className="ft">
          <span className="b2">Cancel</span>
          <span className="b1">Submit</span>
        </div>
      </div>
    </div>
  ),
  Dialog: () => (
    <div className="pv-dialog">
      <div className="ic">!</div>
      <div className="ti">Discard draft?</div>
      <div className="sb">Your changes since 09:14 will be lost.</div>
    </div>
  ),
  Drawer: () => (
    <div className="pv-drawer-wrap">
      <div className="pv-drawer">
        <div className="ti">Filters</div>
        <div className="ln"></div>
        <div className="ln"></div>
        <div className="ln"></div>
      </div>
    </div>
  ),
  Popover: () => (
    <div className="pv-pop">
      <div className="ti">Service availability</div>
      <div className="sb">This service is online for all 36 states and UTs from Apr 2026.</div>
    </div>
  ),
  Tooltip: () => <div className="pv-tip">Verified by Aadhaar OTP</div>,
  SocialLinks: () => (
    <div className="pv-soc">
      <div className="ic">X</div>
      <div className="ic">in</div>
      <div className="ic">G</div>
      <div className="ic">▶</div>
    </div>
  ),
  AccessibilityBar: () => (
    <div className="pv-ab">
      <div className="grp"><span className="b">A−</span><span className="b on">A</span><span className="b">A+</span></div>
      <div className="grp"><span className="b">हि</span><span className="b">EN</span></div>
      <div className="grp"><span className="b">☼</span><span className="b">☾</span></div>
    </div>
  ),
  FocusRing: () => <div className="pv-focus">Submit</div>,
};

/* ───────────────── Group data ───────────────── */
const GROUPS = [
  {
    id: "form",
    name: "Form Elements",
    desc: "Inputs, controls and selection, the foundation of every citizen-facing form, from a 2-field login to a 40-field welfare application.",
    num: "01 / 16 components",
    components: [
      { name: "Button", desc: "Primary action surface, used to commit choices and progress through a flow.", status: "live", preview: "Button" },
      { name: "Link", desc: "In-line text navigation that respects underline, focus and visited states.", status: "live", preview: "Link" },
      { name: "Input", desc: "Single-line text entry, supports prefix, suffix, validation and Indic scripts.", status: "live", preview: "Input" },
      { name: "Textarea", desc: "Multi-line input for grievance text, address details and longform fields.", status: "live", preview: "Textarea" },
      { name: "Checkbox", desc: "Multi-select control for consent, opt-ins and document checklists.", status: "live", preview: "Checkbox" },
      { name: "Radio Button", desc: "Single-choice control for mutually exclusive options, e.g. auth method.", status: "live", preview: "Radio" },
      { name: "Switch / Toggle", desc: "Immediate-effect on/off control for preferences and accessibility modes.", status: "live", preview: "Toggle" },
      { name: "Dropdown Menu", desc: "Compact single-select for fixed-length lists like state, district, language.", status: "live", preview: "Dropdown" },
      { name: "Combobox", desc: "Searchable dropdown for long lists, pincodes, districts, organisations.", status: "live", preview: "Combobox" },
      { name: "Search", desc: "Type-ahead search across services, documents and component library.", status: "live", preview: "Search" },
      { name: "Slider", desc: "Range and single-thumb input for income brackets, age, and filter ranges.", status: "live", preview: "Slider" },
      { name: "Form Field Group", desc: "Composed label + input + help text + error, the canonical form unit.", status: "live", preview: "FormFieldGroup" },
      { name: "Input OTP", desc: "6-digit segmented input with auto-advance, paste support and resend timer.", status: "live", preview: "OTP" },
      { name: "Date-Time Picker", desc: "Calendar-based date selection with Indian holiday awareness and 24h time.", status: "live", preview: "DatePicker" },
      { name: "File Upload", desc: "Drag-and-drop and click-to-browse with progress, mime checks and previews.", status: "live", preview: "FileUpload" },
      { name: "Auto Complete", desc: "Suggestion-driven input for name, place and government scheme lookups.", status: "live", preview: "AutoComplete" },
    ],
  },
  {
    id: "feedback",
    name: "Feedback",
    desc: "Telling people what just happened, what's happening now, and what they need to do next, without overwhelming.",
    num: "02 / 6 components",
    components: [
      { name: "Alert / Toast", desc: "Inline and floating notifications across success, warning, danger and info.", status: "live", preview: "AlertToast" },
      { name: "Progress Indicator", desc: "Linear and stepped progress for forms, uploads and multi-page journeys.", status: "live", preview: "Progress" },
      { name: "Feedback (Rating)", desc: "Star rating + free-text capture for post-service experience surveys.", status: "live", preview: "Rating" },
      { name: "Draft Status Banner", desc: "Persistent banner that confirms drafts are auto-saved and recoverable.", status: "live", preview: "DraftBanner" },
      { name: "SLA Progress Indicator", desc: "Right-to-Service Act timer that shows time remaining against statutory deadline.", status: "live", preview: "SLAProgress" },
      { name: "Spinner", desc: "Indeterminate loader for short waits, API calls, validation, search.", status: "live", preview: "Spinner" },
    ],
  },
  {
    id: "data",
    name: "Data Display",
    desc: "How citizens see their data, their progress and their entitlements, from a single badge to a full case-tracking timeline.",
    num: "03 / 20 components",
    components: [
      { name: "Badge", desc: "Compact status marker, Verified, Under review, Action required.", status: "live", preview: "Badge" },
      { name: "Tag", desc: "Removable label for applied filters, attached documents and category markers.", status: "live", preview: "Tag" },
      { name: "Chip", desc: "Toggleable filter for faceted navigation across long service catalogues.", status: "live", preview: "Chip" },
      { name: "Card", desc: "Surface for a discrete unit of content, service, certificate, scheme.", status: "live", preview: "Card" },
      { name: "Table", desc: "Sortable, paginated rows for transaction history, applications and audit logs.", status: "live", preview: "Table" },
      { name: "Accordion", desc: "Vertically stacked sections for long-form content like FAQs and eligibility.", status: "live", preview: "Accordion" },
      { name: "Carousel", desc: "Slideshow for announcements, schemes and featured services.", status: "live", preview: "Carousel" },
      { name: "Empty State", desc: "Helpful, never apologetic, guides the next action when there's no data.", status: "live", preview: "EmptyState" },
      { name: "Status Pipeline", desc: "Horizontal stepper for application status, Filed → Verified → Issued.", status: "live", preview: "StatusPipeline" },
      { name: "Escalation Tree", desc: "Hierarchical view of grievance levels, SDM, DM, Commissioner.", status: "live", preview: "EscalationTree" },
      { name: "Journey Timeline", desc: "Vertical chronological log of every event in a citizen's case.", status: "live", preview: "JourneyTimeline" },
      { name: "Checklist", desc: "Required-documents view with completion state and inline upload hooks.", status: "live", preview: "Checklist" },
      { name: "Slot Grid", desc: "Time-slot selection for appointments, slots and biometric capture.", status: "live", preview: "SlotGrid" },
      { name: "Chip Group", desc: "Grouped filter chips with single- or multi-select behaviour.", status: "live", preview: "ChipGroup" },
      { name: "Result List Row", desc: "Dense list row for search results, applications and case lists.", status: "live", preview: "ResultListRow" },
      { name: "Receipt Card", desc: "Tamper-evident receipt for payments, submissions and acknowledgements.", status: "live", preview: "ReceiptCard" },
      { name: "List", desc: "Vertically stacked records, people, documents, addresses.", status: "live", preview: "List" },
      { name: "Pagination", desc: "Page-by-page navigation for tables and long result sets.", status: "live", preview: "Pagination" },
      { name: "Stepper", desc: "Multi-step process indicator with completed, active and pending states.", status: "live", preview: "Stepper" },
      { name: "Tab", desc: "Mutually exclusive content panels within a single page.", status: "live", preview: "Tab" },
    ],
  },
  {
    id: "capture",
    name: "Capture & Verification",
    desc: "The hard bits, pulling identity, documents and payments out of the real world and into a verified record.",
    num: "04 / 7 components",
    components: [
      { name: "Biometric Capture", desc: "Fingerprint and face capture frame with retry, quality check and timeout.", status: "live", preview: "Biometric" },
      { name: "Add to DigiLocker", desc: "One-tap save of issued certificates and credentials into DigiLocker.", status: "live", preview: "DigiLocker" },
      { name: "Calendar Event Link", desc: "Generates Google / Outlook / ICS links for appointment confirmations.", status: "live", preview: "CalendarEvent" },
      { name: "Payment Gateway", desc: "Unified surface for UPI, cards and netbanking against BBPS endpoints.", status: "wip", preview: "Payment" },
      { name: "Chart Library", desc: "Bar, line and donut primitives for service dashboards and audit views.", status: "wip", preview: "Chart" },
      { name: "Calendar Scheduler", desc: "Multi-day appointment booking with slot availability and reminders.", status: "wip", preview: "Scheduler" },
      { name: "Segmented Control", desc: "Compact tab-alternative for two- to four-way toggles in dense UIs.", status: "wip", preview: "Segmented" },
    ],
  },
  {
    id: "utility",
    name: "Utility",
    desc: "The connective tissue, navigation, overlays and accessibility primitives that hold every page together.",
    num: "05 / 16 components",
    components: [
      { name: "Navbar", desc: "Top-level navigation with logo, links, language switch and search.", status: "live", preview: "Navbar" },
      { name: "Footer", desc: "Statutory disclosures, helplines and the tricolour bar, every page ends here.", status: "live", preview: "Footer" },
      { name: "Breadcrumb", desc: "Where am I, and how did I get here, for deep service catalogues.", status: "live", preview: "Breadcrumb" },
      { name: "Divider", desc: "Visual separator for sections, lists and form groups, with optional label.", status: "live", preview: "Divider" },
      { name: "Avatar", desc: "Profile representation with initials, image and stacked group variants.", status: "live", preview: "Avatar" },
      { name: "Image", desc: "Loading, error and lazy-load behaviour for document scans and photos.", status: "live", preview: "Image" },
      { name: "Icon Button", desc: "Square action button for compact toolbars and dense interactions.", status: "live", preview: "IconButton" },
      { name: "Badge", desc: "Notification count for nav items, inbox and pending action surfaces.", status: "live", preview: "Badge" },
      { name: "Modal", desc: "Blocking overlay for confirmations, submissions and consent capture.", status: "live", preview: "Modal" },
      { name: "Dialog", desc: "Destructive-action confirmation with explicit accept and dismiss paths.", status: "live", preview: "Dialog" },
      { name: "Drawer", desc: "Side-anchored panel for filters, side navigation and secondary detail.", status: "live", preview: "Drawer" },
      { name: "Popover", desc: "Anchored helper for contextual content, date pickers, menus, info.", status: "live", preview: "Popover" },
      { name: "Tooltip", desc: "Short, non-interactive label for icons, controls and abbreviations.", status: "live", preview: "Tooltip" },
      { name: "Social Links", desc: "Icon row for official handles, X, LinkedIn, YouTube, Koo.", status: "live", preview: "SocialLinks" },
      { name: "Accessibility Bar", desc: "Persistent toolbar for font size, contrast and language preferences.", status: "live", preview: "AccessibilityBar" },
      { name: "Focus Ring", desc: "Token-driven keyboard focus indicator, audited for WCAG 2.1 AA.", status: "live", preview: "FocusRing" },
    ],
  },
];

/* ───────────────── Header ───────────────── */
function Header({ onStub }) {
  return (
    <section className="cx-header">
      <div className="container">
        <div className="cx-crumb">
          <a href="UX4G Homepage.html">Home</a>
          <span className="sep">/</span>
          <span className="current">Components</span>
        </div>
        <div className="cx-title-row">
          <h1 className="cx-title">Components</h1>
          <p className="cx-desc">
            Building blocks for every government digital service, from a simple button
            to a complete identity verification flow.
          </p>
        </div>
      </div>
    </section>
  );
}

/* ───────────────── Sticky group nav ───────────────── */
function GroupTabs({ active, setActive }) {
  const onClick = (id) => {
    const el = document.getElementById("g-" + id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 130;
      window.scrollTo({ top, behavior: "smooth" });
    }
    setActive(id);
  };
  return (
    <div className="cx-tabs-wrap">
      <div className="cx-tabs">
        {GROUPS.map((g) => (
          <button
            key={g.id}
            className={"cx-tab" + (active === g.id ? " active" : "")}
            onClick={() => onClick(g.id)}
          >
            {g.name}
            <span className="tab-count">{g.components.length}</span>
          </button>
        ))}
        <div className="cx-tab-meta">
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
            <span className="dot-live"></span>52 live
          </span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
            <span className="dot-soon"></span>4 in progress
          </span>
        </div>
      </div>
    </div>
  );
}

/* ───────────────── Group section ───────────────── */
function GroupSection({ group, alt, onStub }) {
  const Render = (name) => {
    const C = Previews[name];
    return C ? <C /> : null;
  };
  return (
    <section id={"g-" + group.id} className={"cx-group-section" + (alt ? " alt" : "")}>
      <div className="container">
        <div className="cx-group-head">
          <div>
            <div className="cx-group-num">{group.num}</div>
            <h2 className="cx-group-name">{group.name}</h2>
          </div>
          <p className="cx-group-desc">{group.desc}</p>
        </div>
        <div className="cx-grid">
          {group.components.map((c) => (
            <div
              key={c.name + group.id}
              className={"cx-card" + (c.status === "wip" ? " wip" : "")}
              onClick={() => onStub(c.name)}
            >
              <div className="cx-preview">{Render(c.preview)}</div>
              <div className="cx-meta">
                <div className="cx-meta-left">
                  <h3 className="cx-name">
                    <span className={"status-dot " + (c.status === "live" ? "live" : "wip")}></span>
                    {c.name}
                  </h3>
                  <p className="cx-text">{c.desc}</p>
                </div>
                <span className="cx-arrow">↗</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────────────── Bottom link row ───────────────── */
function Bottom({ onStub }) {
  return (
    <section className="cx-bottom">
      <div className="container">
        <div className="line">
          Looking for developer docs, API references, or code snippets?
          <a onClick={() => onStub("Storybook")}>Visit our Storybook →</a>
        </div>
        <div className="sub">UX4G 3.0 · STORYBOOK · UPDATED 28.04.2026</div>
      </div>
    </section>
  );
}

/* ───────────────── App ───────────────── */
function App() {
  const { toasts, push } = useToasts();
  const [active, setActive] = useState("form");

  const stub = (name) => push(`${name}, page coming soon`);

  // Update active group based on scroll position
  useEffect(() => {
    const onScroll = () => {
      const probe = 200;
      let current = GROUPS[0].id;
      for (const g of GROUPS) {
        const el = document.getElementById("g-" + g.id);
        if (!el) continue;
        const top = el.getBoundingClientRect().top;
        if (top < probe) current = g.id;
      }
      setActive(current);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <Navbar onStub={stub} active="Components" />
      <main className="cx-page">
        <Header onStub={stub} />
        <GroupTabs active={active} setActive={setActive} />
        {GROUPS.map((g, i) => (
          <GroupSection key={g.id} group={g} alt={i % 2 === 1} onStub={stub} />
        ))}
        <Bottom onStub={stub} />
      </main>
      <Toasts items={toasts} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
