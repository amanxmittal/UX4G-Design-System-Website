/* global React, ReactDOM */
const { useState, useEffect, useCallback } = React;

function useToasts() {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2400);
  }, []);
  return { toasts, push };
}
function Toasts({ items }) {
  return (
    <div className="toast-stack">
      {items.map((t) => (
        <div className="toast" key={t.id}>
          <span className="t-mark">i</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}
function Navbar({ onStub }) {
  const links = [
    { l: "Foundations", href: "UX4G Foundations.html" },
    { l: "Fundamentals", href: "UX4G Fundamentals.html" },
    { l: "Components", href: "UX4G Components.html" },
    { l: "Patterns", href: "UX4G Patterns.html" },
  ];
  return (
    <header className="nav">
      <div className="nav-inner">
        <a className="brand" href="UX4G Homepage.html">
          <div className="brand-mark">U4</div>
          <div className="brand-text">
            <div className="row">
              <span className="wordmark">UX4G</span>
              <span className="sub">Design System</span>
            </div>
            <span className="gov">A Government of India Initiative</span>
          </div>
        </a>
        <nav className="nav-links">
          {links.map((x) => (
            <a key={x.l}
               className={"nav-link" + ("Foundations" === x.l ? " active" : "")}
               href={x.href}
            >{x.l}</a>
          ))}
        </nav>
        <a className="btn btn-primary" href="UX4G Homepage.html">← Home</a>
      </div>
    </header>
  );
}

const SECTIONS = [
  { id: "palette",  label: "Colour palette" },
  { id: "semantic", label: "Semantic colours" },
  { id: "neutral",  label: "Neutral colours" },
  { id: "contrast", label: "Contrast & accessibility" },
  { id: "howto",    label: "How to use colour" },
];

function Sidebar({ active, onStub }) {
  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 100, behavior: "smooth" });
  };
  return (
    <aside className="col-side">
      <div className="side-label">On this page</div>
      <ul>
        {SECTIONS.map((s) => (
          <li key={s.id}>
            <a className={active === s.id ? "active" : ""} onClick={() => scrollTo(s.id)}>{s.label}</a>
          </li>
        ))}
        <li><div className="divider"></div></li>
        <li><a className="ext" onClick={() => onStub("Storybook · Colour tokens")}>View tokens in Storybook</a></li>
      </ul>
    </aside>
  );
}

/* Header */
function Header() {
  return (
    <div className="col-header">
      <div className="col-crumb">
        <a href="UX4G Homepage.html">Home</a>
        <span className="sep">/</span>
        <a href="UX4G Foundations.html">Foundations</a>
        <span className="sep">/</span>
        <span className="current">Colour</span>
      </div>
      <h1 className="col-title">Colour</h1>
      <p className="col-desc">
        The UX4G colour system is built for legibility, accessibility, and trust. Every colour has a purpose, nothing is decorative without reason.
      </p>
    </div>
  );
}

/* Ramps */
const PRIMARY_RAMP = [
  { stop: 50,  hex: "#F4F1FF", dark: false },
  { stop: 100, hex: "#E6E0FF", dark: false },
  { stop: 200, hex: "#CDC1FF", dark: false },
  { stop: 300, hex: "#AC9CFF", dark: false },
  { stop: 400, hex: "#8C77FF", dark: false },
  { stop: 500, hex: "#6A4EFF", dark: true, base: true },
  { stop: 600, hex: "#5A3DEB", dark: true },
  { stop: 700, hex: "#4A2BC2", dark: true },
  { stop: 800, hex: "#3A2298", dark: true },
  { stop: 900, hex: "#2A1870", dark: true },
  { stop: 950, hex: "#1B0F4A", dark: true },
];
const SECONDARY_RAMP = [
  { stop: 50,  hex: "#FFF7EA", dark: false },
  { stop: 100, hex: "#FFECCB", dark: false },
  { stop: 200, hex: "#FFD893", dark: false },
  { stop: 300, hex: "#FFC55C", dark: false },
  { stop: 400, hex: "#FFB540", dark: false },
  { stop: 500, hex: "#FFA827", dark: false, base: true },
  { stop: 600, hex: "#E68C0F", dark: true },
  { stop: 700, hex: "#B86E08", dark: true },
  { stop: 800, hex: "#8A5408", dark: true },
  { stop: 900, hex: "#5C3A07", dark: true },
  { stop: 950, hex: "#3A2304", dark: true },
];
const NEUTRAL_RAMP = [
  { stop: 50,  hex: "#FAFAFA", dark: false },
  { stop: 100, hex: "#F5F5F5", dark: false },
  { stop: 200, hex: "#E5E5E5", dark: false },
  { stop: 300, hex: "#D4D4D4", dark: false },
  { stop: 400, hex: "#A3A3A3", dark: false },
  { stop: 500, hex: "#737373", dark: true, base: true },
  { stop: 600, hex: "#525252", dark: true },
  { stop: 700, hex: "#404040", dark: true },
  { stop: 800, hex: "#262626", dark: true },
  { stop: 900, hex: "#171717", dark: true },
  { stop: 950, hex: "#0A0A0A", dark: true },
];

function Ramp({ ramp }) {
  return (
    <div className="ramp">
      {ramp.map((s) => (
        <div
          key={s.stop}
          className={"stop " + (s.dark ? "dark " : "light ") + (s.base ? "base" : "")}
          style={{ background: s.hex }}
        >
          {s.base && <span className="base-mark">BASE</span>}
          <span className="num">{s.stop}</span>
          <span className="hex">{s.hex}</span>
        </div>
      ))}
    </div>
  );
}

function Palette() {
  return (
    <section id="palette" className="col-section">
      <div className="col-section-num">01 / PALETTE</div>
      <h2 className="col-section-title">Colour palette</h2>
      <p className="col-section-lede">
        Each ramp moves from 50 (lightest tint) to 950 (deepest shade). The base, 500, is the colour you'd reach for first.
      </p>

      <div className="pal-block">
        <div className="pal-head">
          <h3 className="pal-name">Primary, Indigo-violet <span className="anchor">#6A4EFF · base 500</span></h3>
          <span className="pal-tag">11 stops · 50 → 950</span>
        </div>
        <Ramp ramp={PRIMARY_RAMP} />
      </div>

      <div className="pal-block">
        <div className="pal-head">
          <h3 className="pal-name">Secondary, Amber <span className="anchor">#FFA827 · base 500</span></h3>
          <span className="pal-tag">11 stops · 50 → 950</span>
        </div>
        <Ramp ramp={SECONDARY_RAMP} />
      </div>

      <div className="pal-block">
        <div className="pal-head">
          <h3 className="pal-name">Neutral, Greyscale <span className="anchor">cool-leaning · base 500</span></h3>
          <span className="pal-tag">11 stops · 50 → 950</span>
        </div>
        <Ramp ramp={NEUTRAL_RAMP} />
      </div>

      <div className="col-callout">
        <strong>Never use colour alone to communicate meaning</strong>, always pair with a label or icon. This is both a WCAG requirement and essential for users with colour blindness.
      </div>
    </section>
  );
}

/* Semantic */
function Semantic() {
  const rows = [
    { name: "Success", role: "Success",  hex: "#106C35", light: "#EBF6EF", use: "Used in SLA indicators when an application is on track, and in confirmation banners after a successful submission." },
    { name: "Warning", role: "Warning",  hex: "#C97A0C", light: "#FFF1DA", use: "Used when SLA is approaching deadline, or to flag actions that require attention but are not blocking." },
    { name: "Error",   role: "Error",    hex: "#DB372D", light: "#FDECEB", use: "Used for form validation failures, system errors, and destructive confirmation buttons." },
    { name: "Info",    role: "Info",     hex: "#1F6FD0", light: "#E8F1FB", use: "Used for help text, neutral system messages, and inline tips that don't require user action." },
  ];
  return (
    <section id="semantic" className="col-section">
      <div className="col-section-num">02 / SEMANTIC</div>
      <h2 className="col-section-title">Semantic colours</h2>
      <p className="col-section-lede">
        Citizens learn the system once. Don't reuse semantic colours for decorative or branding purposes, break the mapping and you break trust.
      </p>
      <div className="sem-grid">
        {rows.map((r) => (
          <div key={r.name} className="sem-row">
            <div className="sw" style={{ background: r.hex }}>
              <span className="hx" style={{ color: "#fff" }}>{r.hex}</span>
            </div>
            <div className="nm">
              <span className="lbl">{r.role}</span>
              <span className="nme">{r.name}</span>
            </div>
            <div className="ex">{r.use}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* Neutral */
function Neutral() {
  const items = [
    { role: "Background",     name: "White",    bg: "#FFFFFF" },
    { role: "Surface",        name: "Grey 50",  bg: "#FAFAFA" },
    { role: "Border",         name: "Grey 200", bg: "#E5E5E5" },
    { role: "Secondary text", name: "Grey 500", bg: "#737373" },
    { role: "Primary text",   name: "Ink",      bg: "#0E0E12" },
  ];
  return (
    <section id="neutral" className="col-section">
      <div className="col-section-num">03 / NEUTRALS</div>
      <h2 className="col-section-title">Neutrals</h2>
      <p className="col-section-lede">
        Use neutrals for everything that isn't an action, status, or accent, backgrounds, surfaces, borders, and the type that fills 90% of any screen.
      </p>
      <div className="neu-grid">
        {items.map((it) => (
          <div key={it.name} className="neu-card">
            <div className="sw" style={{ background: it.bg, borderBottomColor: it.bg === "#FFFFFF" ? "var(--gray-200)" : undefined }}></div>
            <div className="meta">
              <div className="role">{it.role}</div>
              <div className="name">{it.name}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* Contrast */
function Contrast() {
  return (
    <section id="contrast" className="col-section">
      <div className="col-section-num">04 / CONTRAST</div>
      <h2 className="col-section-title">Contrast & accessibility</h2>
      <p className="col-section-lede">
        The same colour can be safe in one place and unsafe in another. These four pairs are the rules to memorise.
      </p>

      <div className="ctr-grid">
        <div className="ctr-card pass">
          <div className="head"><span>✓ PASS · Primary on white</span><span className="ratio">9.4 : 1</span></div>
          <div className="stage" style={{ background: "#fff" }}>
            <div className="lg" style={{ color: "#6A4EFF" }}>Verify identity</div>
            <div className="sm" style={{ color: "#6A4EFF" }}>Primary purple holds up at body size on white.</div>
          </div>
          <div className="rule">Safe for text, links, and primary actions across body and heading sizes.</div>
        </div>

        <div className="ctr-card fail">
          <div className="head"><span>✕ FAIL · Amber on white</span><span className="ratio">2.0 : 1</span></div>
          <div className="stage" style={{ background: "#fff" }}>
            <div className="lg" style={{ color: "#FFA827" }}>Verify identity</div>
            <div className="sm" style={{ color: "#FFA827" }}>Amber on white blurs and disappears for many readers.</div>
          </div>
          <div className="rule">Never use amber as text colour on a white surface, fails WCAG AA at every size.</div>
        </div>

        <div className="ctr-card pass">
          <div className="head"><span>✓ PASS · White on primary</span><span className="ratio">9.4 : 1</span></div>
          <div className="stage" style={{ background: "#6A4EFF" }}>
            <div className="lg" style={{ color: "#fff" }}>Verify identity</div>
            <div className="sm" style={{ color: "rgba(255,255,255,0.9)" }}>Reverses cleanly, the default for primary buttons.</div>
          </div>
          <div className="rule">Safe combination. Use this for primary buttons and dark-mode CTAs.</div>
        </div>

        <div className="ctr-card pass">
          <div className="head"><span>✓ PASS · Ink on amber</span><span className="ratio">11.6 : 1</span></div>
          <div className="stage" style={{ background: "#FFA827" }}>
            <div className="lg" style={{ color: "#0E0E12" }}>Action required</div>
            <div className="sm" style={{ color: "#0E0E12" }}>Amber works as a background, but only with dark text on top.</div>
          </div>
          <div className="rule">Safe when amber is the surface and the text is near-black. This is amber's one and only text role.</div>
        </div>
      </div>

      <div className="ctr-bottom-note">
        <strong>All UX4G components</strong> ship with colour combinations that pass WCAG 2.1 AA contrast requirements. Stay within the system and your designs will, too.
      </div>
    </section>
  );
}

/* How to use */
function HowTo() {
  return (
    <section id="howto" className="col-section">
      <div className="col-section-num">05 / HOW TO USE</div>
      <h2 className="col-section-title">How to use colour</h2>
      <p className="col-section-lede">
        Every pair has a real rendered example so the rule reads before the words do.
      </p>

      <div className="col-dd-pair">
        <div className="col-dd-card do">
          <div className="ddl">✓ Do</div>
          <div className="stg">
            <button className="mini-btn">Submit application</button>
            <button className="mini-btn ghost">Save draft</button>
          </div>
          <div className="rl">Use Primary for the single dominant action per screen, everything else is supporting.</div>
        </div>
        <div className="col-dd-card dont">
          <div className="ddl">✕ Don't</div>
          <div className="stg">
            <div className="mini-dec-purple"></div>
            <div className="mini-dec-purple line"></div>
            <div className="mini-dec-purple"></div>
          </div>
          <div className="rl">Use Primary for decorative shapes, it dilutes the cue users rely on to find the action.</div>
        </div>
      </div>

      <div className="col-dd-pair">
        <div className="col-dd-card do">
          <div className="ddl">✓ Do</div>
          <div className="stg">
            <span className="mini-badge green">● APPROVED</span>
            <span className="mini-badge green">● ON TRACK</span>
            <span className="mini-badge green">● SUBMITTED</span>
          </div>
          <div className="rl">Use semantic colours consistently, green always means success, everywhere.</div>
        </div>
        <div className="col-dd-card dont">
          <div className="ddl">✕ Don't</div>
          <div className="stg">
            <span className="mini-badge green">● NEW FEATURE</span>
            <span className="mini-badge green">● BETA</span>
            <span className="mini-badge green">● PRO PLAN</span>
          </div>
          <div className="rl">Use green for anything other than success, it breaks the meaning citizens have already learned.</div>
        </div>
      </div>

      <div className="col-dd-pair">
        <div className="col-dd-card do">
          <div className="ddl">✓ Do</div>
          <div className="stg" style={{ flexDirection: "column", alignItems: "flex-start", gap: 12, padding: 24 }}>
            <div className="amber-banner">⚠  SLA approaching, 2 days remaining</div>
            <span className="mini-badge amber">● ATTENTION</span>
          </div>
          <div className="rl">Use amber as an accent or warning surface, with dark text on top.</div>
        </div>
        <div className="col-dd-card dont">
          <div className="ddl">✕ Don't</div>
          <div className="stg" style={{ flexDirection: "column", alignItems: "flex-start", gap: 8, padding: 24 }}>
            <div className="mini-text-amber">Your application has been received and is currently under review.</div>
            <div className="mini-text-amber">Expected processing time: 3 working days.</div>
          </div>
          <div className="rl">Use amber for body text on white, it fails contrast at every size.</div>
        </div>
      </div>

      <div className="col-sb-cta">
        <div className="sb-text">
          <strong>Building with UX4G?</strong> Token names, OKLCH values, and dark-mode mappings for every colour live in Storybook.
        </div>
        <a className="sb-link" onClick={(e) => { e.preventDefault(); }}>Open colour tokens ↗</a>
      </div>
    </section>
  );
}

function App() {
  const { toasts, push } = useToasts();
  const stub = (n) => push(`${n}, page coming soon`);
  const [active, setActive] = useState("palette");

  useEffect(() => {
    const onScroll = () => {
      const probe = 180;
      let cur = SECTIONS[0].id;
      for (const s of SECTIONS) {
        const el = document.getElementById(s.id);
        if (!el) continue;
        if (el.getBoundingClientRect().top < probe) cur = s.id;
      }
      setActive(cur);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <Navbar onStub={stub} />
      <main className="col-page">
        <div className="col-layout">
          <div className="col-main">
            <Header />
            <Palette />
            <Semantic />
            <Neutral />
            <Contrast />
            <HowTo />
          </div>
          <Sidebar active={active} onStub={stub} />
        </div>
      </main>
      <Toasts items={toasts} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
